import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useScene } from '../three/sceneStore';
import { bindScroll } from '../three/scrollStore';
import ArticleBody from '../components/ArticleBody';
import { extractHeadings } from '../content/markdown';
import Frame from '../components/Frame';
import { getArticle, getSiblings, formatDate } from '../content/articles';
import './BlogPost.css';

/**
 * UN ARTICLE.
 *
 * Ici la règle du site s'inverse : ailleurs le contenu laisse la place à la
 * scène, ici la scène s'efface devant le texte.
 *
 * Concrètement, la 3D n'occupe que l'en-tête — on entre dans l'article par la
 * même traversée que le reste du site — puis le corps se pose sur un aplat
 * papier plein qui recouvre le canvas. Un article de douze minutes, c'est trois
 * à quatre minutes de défilement : une scène qui tourne en continu derrière le
 * texte, c'est de la batterie brûlée, un contraste qui bouge sous les lignes et
 * une lecture qu'on abandonne. La 3D fait l'entrée, le papier fait la lecture.
 */

// Le sommaire suit la lecture par IntersectionObserver et non par un écouteur
// de défilement : l'écouteur se déclenche à chaque pixel, chaque fois suivi
// d'un calcul de position qui force un recalcul de mise en page. L'observer ne
// réveille le JS qu'aux franchissements de seuil.
//
// La marge '-140px 0px -70%' réduit la zone de détection à une bande étroite
// sous le cadre d'interface : sans elle, deux ou trois titres sont visibles en
// même temps et le surlignage clignote entre eux.
function useActiveHeading(headings) {
  const [activeId, setActiveId] = useState(headings[0]?.id ?? null);

  useEffect(() => {
    if (!headings.length) return undefined;

    // On mémorise la visibilité de CHAQUE titre plutôt que de réagir au seul
    // événement reçu. L'observer ne transmet que les titres dont l'état vient
    // de changer : en se fiant à ce seul lot, un défilement rapide (ou un saut
    // direct via une ancre) livre un événement de SORTIE comme dernier message,
    // et le sommaire reste bloqué sur la section précédente.
    const visible = new Map();

    const resolve = () => {
      // Premier titre encore dans la bande de lecture, dans l'ordre du
      // document — et non dans l'ordre d'arrivée des événements.
      const inBand = headings.find((h) => visible.get(h.id));
      if (inBand) {
        setActiveId(inBand.id);
        return;
      }
      // Aucun titre dans la bande : on est au milieu d'une longue section. Le
      // titre courant est alors le dernier qu'on a dépassé vers le haut.
      const passed = headings.filter((h) => {
        const el = document.getElementById(h.id);
        return el && el.getBoundingClientRect().top < 140;
      });
      if (passed.length) setActiveId(passed[passed.length - 1].id);
    };

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => visible.set(e.target.id, e.isIntersecting));
        resolve();
      },
      { rootMargin: '-140px 0px -70% 0px', threshold: 0 },
    );

    headings
      .map((h) => document.getElementById(h.id))
      .filter(Boolean)
      .forEach((n) => observer.observe(n));

    return () => observer.disconnect();
  }, [headings]);

  return activeId;
}

function Missing() {
  return (
    <>
      <main className="run">
        <section className="station station--missing">
          <div className="station__inner">
            <p className="t-tag">Erreur 404</p>
            <h1 className="t-title">
              Article
              <br />
              <span className="t-soft flare">introuvable</span>
            </h1>
            <p className="t-lead">
              Cet article n&apos;existe pas ou a été déplacé. Les autres sont toujours là.
            </p>
            <Link to="/blog" className="act">
              <span>Retour au journal</span>
            </Link>
          </div>
        </section>
      </main>
      <Frame meter={false} />
    </>
  );
}

export default function BlogPost() {
  const { id } = useParams();
  const article = getArticle(id);

  const headings = useMemo(() => (article ? extractHeadings(article.content) : []), [article]);
  const activeId = useActiveHeading(headings);

  useScene({ depth: 14 });
  useEffect(() => bindScroll(), []);

  // Un article ouvert depuis un autre doit commencer en haut : sans ça, le
  // routeur conserve la position et on atterrit au milieu du texte.
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  if (!article) return <Missing />;

  const { prev, next } = getSiblings(article.id);

  return (
    <>


      <main className="run post">
        <header className="post__head veil">
          <Link to="/blog" className="post__back t-tag">
            ← Retour au journal
          </Link>

          <p className="t-tag post__cat">
            <span className="flare">{article.category}</span>
          </p>

          <h1 className="t-title post__title">{article.title}</h1>

          <p className="t-lead post__excerpt">{article.excerpt}</p>

          <div className="post__meta t-tag">
            <time dateTime={article.date}>{formatDate(article.date)}</time>
            <span>{article.readTime} min de lecture</span>
            <span>Par {article.author}</span>
          </div>
        </header>

        <div className="post__body">
          <div className="post__grid">
            {headings.length > 1 && (
              <aside className="post__toc" aria-label="Sommaire">
                <p className="t-tag post__toc-title">Sommaire</p>
                <ol className="post__toc-list">
                  {headings.map((h, i) => (
                    <li key={h.id}>
                      <a
                        href={`#${h.id}`}
                        className={h.id === activeId ? 'is-on' : ''}
                        aria-current={h.id === activeId ? 'true' : undefined}
                      >
                        <span className="post__toc-n">{String(i + 1).padStart(2, '0')}</span>
                        {h.text}
                      </a>
                    </li>
                  ))}
                </ol>
              </aside>
            )}

            <article className="post__text">
              <ArticleBody content={article.content} />

              {/* Pas de sources, pas de panneau : un bloc vide avec un titre
                  donne l'impression d'un contenu qui n'a pas chargé. */}
              {article.sources.length > 0 && (
                <section className="post__sources">
                  <h2 className="t-tag post__block-title">Sources et ressources</h2>
                  <ul>
                    {article.sources.map((s) => (
                      <li key={s.url}>
                        <a href={s.url} target="_blank" rel="noopener noreferrer">
                          <span>{s.title}</span>
                          <span aria-hidden="true">↗</span>
                        </a>
                      </li>
                    ))}
                  </ul>
                </section>
              )}

              <section className="post__pillar">
                <h2 className="t-tag post__block-title">Article connexe</h2>
                <p className="t-body">
                  Cet article fait partie d&apos;une stratégie de contenu plus large. Découvre le
                  guide complet :
                </p>
                <Link to={article.relatedPillar.url} className="post__pillar-link">
                  {article.relatedPillar.title} <span aria-hidden="true">→</span>
                </Link>
              </section>

              <section className="post__cta">
                <h2 className="t-title post__cta-title">
                  Besoin d&apos;aide pour
                  <br />
                  <span className="t-soft">mettre en place ?</span>
                </h2>
                <p className="t-body">
                  Ces techniques fonctionnent, mais les mettre en place prend du temps. Je peux le
                  faire pour toi.
                </p>
                <Link to="/demarrer" className="act act--flare">
                  <span>Décrire mon besoin</span>
                </Link>
              </section>
            </article>
          </div>

          {(prev || next) && (
            <nav className="post__siblings" aria-label="Autres articles">
              {prev ? (
                <Link to={`/blog/${prev.id}`} className="post__sibling">
                  <span className="t-tag">← Précédent</span>
                  <span className="post__sibling-name">{prev.title}</span>
                </Link>
              ) : (
                <span />
              )}
              {next && (
                <Link to={`/blog/${next.id}`} className="post__sibling post__sibling--next">
                  <span className="t-tag">Suivant →</span>
                  <span className="post__sibling-name">{next.title}</span>
                </Link>
              )}
            </nav>
          )}
        </div>
      </main>

      <Frame />
    </>
  );
}
