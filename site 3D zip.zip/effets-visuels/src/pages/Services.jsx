import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useScene } from '../three/sceneStore';
import { bindScroll } from '../three/scrollStore';
import Frame from '../components/Frame';
import './Services.css';

/**
 * SERVICES — la traversée détaillée.
 *
 * Même grammaire que la home (des stations qu'on franchit), mais le contenu y
 * est plus dense : c'est la page où l'on vient chercher le détail, pas
 * l'impression. Les quatre expertises sont donc en liste verticale, chacune
 * avec son numéro et sa place — et non en grille de tuiles, qui les rendrait
 * interchangeables et imposerait à toutes la longueur de la plus courte.
 */

// Contenu repris tel quel du site existant. Le premier service est
// volontairement plus détaillé : c'est l'offre phare, la seule à porter une
// liste de livrables.
const SERVICES = [
  {
    n: '01',
    title: 'Prospection IA',
    desc: 'Des séquences automatisées et hyper-personnalisées, générées et affinées par IA à partir de vos données CRM.',
    points: [
      'Personnalisation par IA à l’échelle',
      'Scoring et priorisation des leads',
      'Séquences multicanal (email, LinkedIn)',
    ],
  },
  {
    n: '02',
    title: 'Workflows no-code',
    desc: 'Vos outils connectés entre eux — CRM, mail, calendrier, facturation — sans dépendre d’un dev à chaque changement.',
  },
  {
    n: '03',
    title: 'Growth hacking',
    desc: 'Des stratégies d’acquisition agressives et mesurables, pensées pour scaler sans exploser les coûts.',
  },
  {
    n: '04',
    title: 'Cold emailing',
    desc: 'Infrastructure technique (domaines, warm-up, rotation) pour une délivrabilité proche de 99 % et zéro spam.',
  },
];

const STATS = [
  { value: '3x', label: 'plus de leads qualifiés en moyenne' },
  { value: '-70%', label: 'de temps passé sur la prospection manuelle' },
  { value: '99%', label: 'de délivrabilité visée sur le cold email' },
];

const TOOLS = ['N8N', 'Make', 'HubSpot', 'Lemlist', 'Airtable', 'Zapier', 'Notion', 'Slack'];

export default function Services() {
  useScene({ depth: 30 });
  useEffect(() => bindScroll(), []);

  return (
    <>


      <main className="run">
        {/* ------------------------------------------------------------ 00 */}
        <section className="station station--hero">
          <div className="station__inner">
            <p className="t-tag">Expertises</p>
            <h1 className="t-display hero__title hero__title--long">
              Ce que je fais
              <br />
              tourner <span className="t-soft flare">pour vous</span>
            </h1>
            <div className="hero__foot">
              <p className="t-lead">
                Quatre briques, un seul objectif : remplir votre pipeline sans vous faire perdre de
                temps sur des tâches à faible valeur.
              </p>
              <Link to="/demarrer" className="act act--flare">
                <span>Réserver un appel</span>
              </Link>
            </div>
          </div>
        </section>

        {/* ------------------------------------------------------------ 01 */}
        <section className="station station--offer veil">
          <p className="t-tag station__tag">
            <span className="station__n">01</span>
            Les prestations
          </p>

          <ol className="offer">
            {SERVICES.map((service) => (
              <li key={service.n} className="offer__row">
                <span className="offer__n t-tag">{service.n}</span>
                <div className="offer__main">
                  <h2 className="offer__title">{service.title}</h2>
                  <p className="t-body offer__desc">{service.desc}</p>
                  {service.points && (
                    <ul className="offer__points">
                      {service.points.map((point) => (
                        <li key={point}>{point}</li>
                      ))}
                    </ul>
                  )}
                </div>
              </li>
            ))}
          </ol>
        </section>

        {/* ------------------------------------------------------------ 02 */}
        <section className="station station--stats">
          <p className="t-tag station__tag">
            <span className="station__n">02</span>
            Ce que ça donne
          </p>
          <div className="stats">
            {STATS.map((stat) => (
              <div key={stat.label} className="stat">
                <span className="stat__value">{stat.value}</span>
                <p className="stat__label t-body">{stat.label}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ------------------------------------------------------------ 03
            Bandeau d'outils. Défilement en CSS pur : le contenu est dupliqué
            une fois et translaté de 0 à -50 % — comme les deux moitiés sont
            identiques, la boucle est invisible, et aucun JS ne tourne. */}
        <section className="station station--tools">
          <p className="t-tag station__tag">
            <span className="station__n">03</span>
            La pile technique
          </p>
          <div className="belt">
            <div className="belt__track">
              {[...TOOLS, ...TOOLS].map((tool, i) => (
                <span className="belt__item" key={`${tool}-${i}`} aria-hidden={i >= TOOLS.length}>
                  {tool}
                  <span className="belt__dot" />
                </span>
              ))}
            </div>
          </div>
        </section>

        {/* ------------------------------------------------------------ 04 */}
        <section className="station station--end">
          <div className="station__inner">
            <h2 className="t-display end__title">
              On regarde
              <br />
              <span className="t-soft">votre process ?</span>
            </h2>
            <Link to="/demarrer" className="act act--flare">
              <span>Décrire mon besoin</span>
            </Link>
          </div>
        </section>
      </main>

      <Frame />
    </>
  );
}
