import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useScene } from '../three/sceneStore';
import { bindScroll } from '../three/scrollStore';
import ArticleList from '../components/ArticleList';
import Frame from '../components/Frame';
import { getCluster, getArticlesByCategories, PILLAR, CLUSTERS } from '../content/articles';
import './Cluster.css';

/**
 * UNE BRANCHE — page cluster.
 *
 * Un seul composant pour les trois : ils ont strictement la même structure,
 * seul le contenu change (voir CLUSTERS dans content/articles.js). Trois
 * fichiers quasi identiques, ce serait trois endroits à corriger au prochain
 * ajustement.
 *
 * Le `slug` arrive en prop depuis App.jsx plutôt que d'être déduit de l'URL :
 * la route est déclarée à un seul endroit, et une faute de frappe casse le
 * build au lieu de produire une page vide en production.
 *
 * Chaque page remonte vers le guide en haut ET renvoie vers les deux autres
 * branches en bas : aucune page de l'arborescence n'est un cul-de-sac.
 */
export default function Cluster({ slug }) {
  const cluster = getCluster(slug);
  const articles = getArticlesByCategories(cluster.categories);
  const others = CLUSTERS.filter((c) => c.slug !== slug);

  useScene({ depth: 22 });
  useEffect(() => bindScroll(), []);

  // Le contenu change d'une branche à l'autre : on repart du haut.
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [slug]);

  return (
    <>


      <main className="run">
        <section className="station station--branch veil">
          <div className="branch-head">
            <Link to={PILLAR.url} className="branch-head__back t-tag">
              ← {PILLAR.title}
            </Link>

            <p className="t-tag">
              <span className="flare">{cluster.label}</span>
            </p>

            <h1 className="t-display branch-head__title">
              {cluster.title}
              <br />
              <span className="t-soft">{cluster.accent}</span>
            </h1>

            <p className="t-lead branch-head__intro">{cluster.intro}</p>
          </div>

          <div className="branch-list">
            <p className="t-tag station__tag">
              <span className="station__n">{String(articles.length).padStart(2, '0')}</span>
              {articles.length > 1 ? 'Articles' : 'Article'}
            </p>
            <ArticleList articles={articles} />
          </div>
        </section>

        {/* Les deux autres branches : on referme la boucle du maillage. */}
        <section className="station station--others">
          <p className="t-tag station__tag">Explorer aussi</p>
          <div className="others">
            {others.map((other) => (
              <Link key={other.slug} to={other.slug} className="other">
                <span className="other__label t-tag">{other.label}</span>
                <span className="other__title">
                  {other.title} <span className="t-soft">{other.accent}</span>
                </span>
                <span className="other__go" aria-hidden="true">
                  →
                </span>
              </Link>
            ))}
          </div>

          <div className="branch-cta">
            <h2 className="t-title branch-cta__title">
              On regarde
              <br />
              <span className="t-soft">votre cas ?</span>
            </h2>
            <Link to="/demarrer" className="act act--flare">
              <span>Décrire mon besoin</span>
            </Link>
          </div>
        </section>
      </main>

      <Frame />
    </>
  );
}
