import { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Frame from '../components/Frame';
import ChoixBesoin from '../components/ChoixBesoin';
import { AVIS } from '../content/avis';
import { useScene, sceneState } from '../three/sceneStore';
import { RESPIRATION } from '../three/Atelier';
import { bindScroll, scrollState } from '../three/scrollStore';
import './Home.css';

/**
 * LA HOME EST UNE TRAVERSÉE.
 *
 * Un canvas fixe occupe tout l'écran, derrière le contenu. Le document, lui,
 * défile normalement — et la caméra lit cette position pour avancer dans la
 * scène (voir Rig dans Atelier.jsx, et le pourquoi du scroll natif dans
 * scrollStore.js).
 *
 * Les deux avancent à des vitesses différentes : la caméra franchit 74 unités
 * quand le contenu parcourt six écrans. C'est ce décalage qui donne la
 * profondeur — au même rythme, l'ensemble paraîtrait plat.
 *
 * Conséquence importante de cette architecture : le contenu ne dépend pas du
 * canvas. Si le WebGL n'est pas disponible ou échoue, il reste un site complet,
 * lisible, qui défile.
 */


// Fenêtre de défilement pendant laquelle la scène bascule dans le noir. Elle
// est centrée sur la station de respiration — la phrase « chaque lead non
// traité est une vente qui ne se refera pas ». C'est le seul moment de la page
// où le contenu se tait, donc le seul où la scène peut prendre toute la place.
//
// La position vient d'Atelier.jsx, partagée avec celle de la masse vermillon :
// les deux effets doivent se produire au même endroit, et une seule constante
// évite qu'ils divergent au prochain ajout de section.
const NUIT_DEBUT = RESPIRATION - 0.11;
const NUIT_FIN = RESPIRATION + 0.11;
// Part de la fenêtre consacrée au fondu d'entrée et de sortie. Une bascule
// franche ferait clignoter la page ; un quart de la fenêtre de chaque côté
// laisse le temps de voir la lumière tomber.
const FONDU = 0.3;

/**
 * Pilote le basculement jour / nuit.
 *
 * La valeur est écrite à deux endroits : dans sceneState, lu par la scène 3D à
 * chaque image, et dans une variable CSS, qui fait suivre toute la mise en page
 * (voir --night dans index.css). Les deux DOIVENT bouger ensemble : la scène
 * seule laisserait du texte noir sur un fond noir.
 *
 * L'écriture CSS est conditionnée à un écart d'un centième. Poser une custom
 * property sur :root invalide le style de tout le document ; le faire à chaque
 * image, y compris quand la page est immobile, coûterait bien plus cher que
 * l'effet lui-même.
 */
function useNuit() {
  useEffect(() => {
    let raf;
    let dernier = -1;

    const tick = () => {
      const p = scrollState.progress;
      let nuit = 0;

      if (p > NUIT_DEBUT && p < NUIT_FIN) {
        const local = (p - NUIT_DEBUT) / (NUIT_FIN - NUIT_DEBUT);
        // Trapèze : montée, plateau, descente.
        nuit = Math.min(1, Math.min(local, 1 - local) / FONDU);
      }

      sceneState.night = nuit;

      if (Math.abs(nuit - dernier) > 0.01) {
        dernier = nuit;
        document.documentElement.style.setProperty('--night', nuit.toFixed(3));
      }

      raf = requestAnimationFrame(tick);
    };

    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      // On quitte la page en pleine nuit si l'on clique un lien au milieu de la
      // section : sans cette remise à zéro, la page suivante s'ouvrirait dans
      // le noir.
      sceneState.night = 0;
      document.documentElement.style.setProperty('--night', '0');
    };
  }, []);
}

function Station({ n, label, align = 'left', children }) {
  return (
    <section className={`station station--${align}`}>
      <div className="station__inner">
        <p className="t-tag station__tag">
          <span className="station__n">{n}</span>
          {label}
        </p>
        {children}
      </div>
    </section>
  );
}

export default function Home() {
  const navigate = useNavigate();
  useScene({ depth: 74, bloom: true });
  useEffect(() => bindScroll(), []);
  useNuit();

  return (
    <>


      <main className="run">
        {/* ------------------------------------------------------------ 00 */}
        <section className="station station--hero">
          <div className="station__inner">
            <p className="t-tag hero__over">Génération de leads B2B — Automatisation</p>
            <h1 className="t-display hero__title">
              On code
              <br />
              votre <span className="t-soft flare">croissance</span>
            </h1>
            <div className="hero__foot">
              <p className="t-lead">
                J&apos;aide les entreprises B2B à générer des leads qualifiés en pilote
                automatique, et à éliminer les tâches répétitives.
              </p>
              <Link to="/demarrer" className="act act--flare">
                <span>Démarrer</span>
              </Link>
            </div>
          </div>
          <p className="t-tag hero__cue">Défilez pour entrer</p>
        </section>

        {/* ------------------------------------------------------------ 01
            La qualification passe AVANT le discours. Un visiteur qui vient de
            lire l'accroche est au maximum de son intérêt : lui demander de
            cliquer sur la phrase qui décrit sa situation coûte beaucoup moins
            qu'un « prendre rendez-vous », et la suite du parcours se joue sur
            une page dédiée. Le reste de la page reste là pour ceux qui veulent
            d'abord comprendre. */}
        <section className="station station--left station--besoin veil">
          <div className="besoin-home">
            <p className="t-tag station__tag">
              <span className="station__n">01</span>
              Par où on commence
            </p>
            <h2 className="t-title besoin-home__titre">
              Quel est
              <br />
              ton <span className="t-soft flare">besoin ?</span>
            </h2>
            <p className="t-lead">
              Choisissez la situation qui ressemble le plus à la vôtre. Trois questions plus loin,
              vous avez une proposition chiffrée.
            </p>
            <ChoixBesoin onChoix={(id) => navigate('/demarrer', { state: { besoin: id } })} />
          </div>
        </section>

        {/* ------------------------------------------------------------ 02 */}
        <Station n="02" label="La méthode">
          <h2 className="t-title">
            Trois temps,
            <br />
            <span className="t-soft">zéro friction</span>
          </h2>
          <ol className="steps">
            <li>
              <span className="steps__n t-tag">01</span>
              <div>
                <h3>Audit</h3>
                <p className="t-body">
                  On cartographie votre process commercial actuel et on identifie ce qui vous
                  coûte du temps et des leads.
                </p>
              </div>
            </li>
            <li>
              <span className="steps__n t-tag">02</span>
              <div>
                <h3>Automatisation</h3>
                <p className="t-body">
                  On construit les workflows, les séquences et les intégrations sur-mesure — pas
                  de solution générique.
                </p>
              </div>
            </li>
            <li>
              <span className="steps__n t-tag">03</span>
              <div>
                <h3>Scale</h3>
                <p className="t-body">
                  On pilote, on mesure, on ajuste. La machine tourne, vous vous concentrez sur la
                  conversion.
                </p>
              </div>
            </li>
          </ol>
        </Station>

        {/* ------------------------------------------------------------ 02 */}
        <Station n="03" label="Expertises" align="right">
          <h2 className="t-title">
            Une pile
            <br />
            qui <span className="t-soft">convertit</span>
          </h2>
          <ul className="skills">
            <li>
              <span className="t-tag">A</span>
              <h3>Prospection IA</h3>
              <p className="t-body">
                Séquences automatisées et hyper-personnalisées, générées et optimisées par IA.
              </p>
            </li>
            <li>
              <span className="t-tag">B</span>
              <h3>Workflows no-code</h3>
              <p className="t-body">
                Vos outils connectés entre eux : des heures récupérées chaque semaine.
              </p>
            </li>
            <li>
              <span className="t-tag">C</span>
              <h3>Growth hacking</h3>
              <p className="t-body">
                Des stratégies d&apos;acquisition pensées pour scaler sans exploser les coûts.
              </p>
            </li>
            <li>
              <span className="t-tag">D</span>
              <h3>Cold emailing</h3>
              <p className="t-body">
                Infrastructure technique solide pour une délivrabilité proche de 99 %.
              </p>
            </li>
          </ul>
        </Station>

        {/* ------------------------------------------------------------ 04
            Les avis viennent APRÈS les expertises, jamais avant : une preuve
            n'a de valeur que si l'on sait déjà ce qu'elle prouve. Chacun porte
            un chiffre — c'est ce qui les sépare d'un « super travail, je
            recommande » dont le lecteur ne retient rien. */}
        <section className="station station--left station--avis veil">
          <div className="avis-bloc">
            <p className="t-tag station__tag">
              <span className="station__n">04</span>
              Ce qu'ils en disent
            </p>

            <ul className="avis">
              {AVIS.map((a) => (
                <li key={a.nom} className="avis__item">
                  <p className="avis__chiffre">
                    {a.metrique}
                    <span className="avis__unite">{a.unite}</span>
                  </p>
                  <blockquote className="avis__citation">{a.citation}</blockquote>
                  <footer className="avis__qui t-tag">
                    <span className="avis__nom">{a.nom}</span>
                    <span>{a.role}</span>
                  </footer>
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* ------------------------------------------------------------
            Respiration : une phrase, rien d'autre. C'est ici que la caméra
            traverse la masse vermillon — le texte doit s'effacer devant la
            scène, pas rivaliser avec elle. */}
        <section className="station station--void">
          <p className="t-title void__line">
            Chaque lead non traité
            <br />
            est une vente <span className="t-soft flare">qui ne se refera pas</span>
          </p>
        </section>

        {/* ------------------------------------------------------------ 04 */}
        <Station n="05" label="Le journal">
          <h2 className="t-title">
            Ce que j&apos;apprends
            <br />
            <span className="t-soft">en le faisant</span>
          </h2>
          <p className="t-lead">
            Guides pratiques sur l&apos;automatisation, le scraping et la génération de leads.
          </p>
          <Link to="/blog" className="act">
            <span>Lire les articles</span>
          </Link>
        </Station>

        {/* ------------------------------------------------------------ 05 */}
        <section className="station station--end">
          <div className="station__inner">
            <h2 className="t-display end__title">
              On automatise
              <br />
              <span className="t-soft">votre pipeline ?</span>
            </h2>
            <Link to="/demarrer" className="act act--flare">
              <span>Réserver un appel</span>
            </Link>
          </div>
        </section>
      </main>

      <Frame />
    </>
  );
}
