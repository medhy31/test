import { useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Frame from '../components/Frame';
import { useScene } from '../three/sceneStore';
import { bindScroll } from '../three/scrollStore';

/**
 * Page 404 — attrape-tout.
 *
 * Sans elle, une URL inconnue rend une page entièrement vide : le routeur ne
 * trouve aucune correspondance et n'affiche rien du tout, sans la moindre
 * indication ni moyen de repartir. Le cas n'est pas théorique — les anciennes
 * adresses de démonstration (/demo1 à /demo4, /final) ont été supprimées et
 * peuvent rester en signet ou en lien externe.
 */
export default function NotFound() {
  const { pathname } = useLocation();

  useScene({ depth: 10 });
  useEffect(() => bindScroll(), []);

  return (
    <>

      <main className="run">
        <section className="station station--missing veil">
          <div className="station__inner">
            <p className="t-tag">Erreur 404</p>
            <h1 className="t-title">
              Page
              <br />
              <span className="t-soft flare">introuvable</span>
            </h1>
            <p className="t-lead">
              L&apos;adresse <code className="t-tag">{pathname}</code> ne correspond à aucune page.
              Elle a peut-être été déplacée ou supprimée.
            </p>
            <Link to="/" className="act">
              <span>Retour à l&apos;accueil</span>
            </Link>
          </div>
        </section>
      </main>

      <Frame meter={false} />
    </>
  );
}
