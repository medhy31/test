import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useScene } from '../three/sceneStore';
import { bindScroll } from '../three/scrollStore';
import Frame from '../components/Frame';
import ArticleList from '../components/ArticleList';
import { ARTICLES_BY_DATE, CATEGORIES, PILLAR } from '../content/articles';
import './Blog.css';

/**
 * LE JOURNAL — index.
 *
 * Pas de grille de cartes : un INDEX, au sens d'un catalogue imprimé. Chaque
 * article occupe une ligne pleine largeur, numérotée, séparée par un filet.
 *
 * Le choix n'est pas décoratif. Une grille de vignettes traite tous les
 * articles comme des produits interchangeables et impose une longueur de titre ;
 * une liste laisse le titre respirer à la taille où il se lit vraiment, garde
 * les métadonnées alignées d'une ligne à l'autre — donc comparables — et tient
 * la même promesse que le reste du site : de l'industriel, des traits, des
 * numéros.
 */

const ALL = 'Tous';

export default function Blog() {
  const [active, setActive] = useState(ALL);

  useScene({ depth: 20 });
  useEffect(() => bindScroll(), []);

  const visible =
    active === ALL ? ARTICLES_BY_DATE : ARTICLES_BY_DATE.filter((a) => a.category === active);

  return (
    <>


      <main className="run">
        <section className="station station--index veil">
          <div className="index__head">
            <p className="t-tag">Le journal</p>
            <h1 className="t-display index__title">
              Articles
              <br />
              <span className="t-soft">techniques</span>
            </h1>
            <p className="t-lead">
              Guides pratiques sur l&apos;automatisation, le scraping et la génération de leads.
            </p>
          </div>

          {/* Filtres — en mono et sans fond : ce sont des repères de tri, pas
              des boutons d'action. Le seul signe d'état est le vermillon et le
              filet sous le libellé actif. */}
          <div className="index__filters" role="tablist" aria-label="Filtrer par catégorie">
            {[ALL, ...CATEGORIES].map((cat) => {
              const on = cat === active;
              return (
                <button
                  key={cat}
                  type="button"
                  role="tab"
                  aria-selected={on}
                  className={`index__filter ${on ? 'is-on' : ''}`}
                  onClick={() => setActive(cat)}
                >
                  {cat}
                  <span className="index__filter-n">
                    {cat === ALL
                      ? ARTICLES_BY_DATE.length
                      : ARTICLES_BY_DATE.filter((a) => a.category === cat).length}
                  </span>
                </button>
              );
            })}
          </div>

          <ArticleList articles={visible} />

          {visible.length === 0 && (
            <p className="index__empty t-lead">
              Aucun article dans « {active} » pour l&apos;instant.{' '}
              <button type="button" className="index__reset" onClick={() => setActive(ALL)}>
                Tout afficher
              </button>
            </p>
          )}
        </section>

        {/* Renvoi vers la page pilier : c'est la tête de l'arborescence
            éditoriale, elle doit être atteignable depuis l'index. */}
        <section className="station station--pillar">
          <div className="station__inner">
            <p className="t-tag">Aller plus loin</p>
            <h2 className="t-title">
              Le guide
              <br />
              <span className="t-soft">complet</span>
            </h2>
            <p className="t-lead">
              Tous ces articles font partie d&apos;un ensemble : le guide couvre l&apos;automatisation
              B2B de bout en bout.
            </p>
            <Link to={PILLAR.url} className="act">
              <span>Ouvrir le guide</span>
            </Link>
          </div>
        </section>
      </main>

      <Frame />
    </>
  );
}
