import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import Frame from '../components/Frame';
import { useScene } from '../three/sceneStore';
import { bindScroll } from '../three/scrollStore';
import './Apropos.css';

/**
 * À PROPOS.
 *
 * La seule page du site où quelqu'un apparaît. Tout le reste parle de systèmes,
 * de volumes et de méthode — sur une prestation de ce type, le client achète
 * aussi la personne, et il doit pouvoir la regarder.
 *
 * Le portrait a été retraité pour que son fond porte exactement la couleur de
 * la page (#f2f0ec) : sans ça, une photo de studio sur fond blanc froid pose un
 * rectangle plus clair au milieu de l'ivoire, et l'image se lit comme une
 * vignette rapportée plutôt que comme une partie de la mise en page.
 */

const REPERES = [
  {
    cle: 'Formation',
    lignes: ['BTS NDRC — Négociation et digitalisation de la relation client', 'Licence Marketing digital'],
  },
  {
    cle: 'Expérience',
    lignes: ['2 ans en génération de leads et automatisation B2B', '20 projets livrés, plus de 200 000 leads extraits'],
  },
  {
    cle: 'Où',
    lignes: ['France', 'Disponible à distance'],
  },
];

export default function Apropos() {
  useScene({ depth: 14 });
  useEffect(() => bindScroll(), []);

  return (
    <>
      <main className="run">
        <section className="station station--apropos">
          <div className="apropos">
            {/* Le portrait passe en premier dans le DOM : sur mobile, la colonne
                s'empile et c'est le visage qu'on doit voir en arrivant, pas une
                étiquette. */}
            <figure className="apropos__portrait">
              <img
                src="/romain.jpg"
                alt="Portrait de Romain Mention"
                width="1000"
                height="1250"
                loading="eager"
              />
            </figure>

            <div className="apropos__texte">
              <p className="t-tag">Qui je suis</p>

              <h1 className="apropos__nom">
                Romain
                <br />
                <span className="t-soft">Mention</span>
              </h1>

              <p className="apropos__role t-tag">
                Consultant IA agentique <span className="flare">&amp;</span> développeur no-code
              </p>

              <p className="t-lead apropos__accroche">
                Création d&apos;agents IA, automatisation des processus métiers. Je transforme les
                idées en solutions intelligentes.
              </p>

              <dl className="reperes">
                {REPERES.map((r) => (
                  <div key={r.cle} className="repere">
                    <dt className="t-tag">{r.cle}</dt>
                    <dd>
                      {r.lignes.map((l) => (
                        <span key={l}>{l}</span>
                      ))}
                    </dd>
                  </div>
                ))}
              </dl>

              <div className="apropos__actions">
                <Link to="/demarrer" className="act act--flare">
                  <span>Me contacter</span>
                </Link>
                <a
                  className="act"
                  href="https://www.linkedin.com/in/romain-mention-665b03210/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <span>LinkedIn ↗</span>
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Frame meter={false} />
    </>
  );
}
