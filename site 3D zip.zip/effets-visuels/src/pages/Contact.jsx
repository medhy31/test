import { useEffect, useState } from 'react';
import { useScene } from '../three/sceneStore';
import { bindScroll } from '../three/scrollStore';
import Frame from '../components/Frame';
import './Contact.css';

/**
 * CONTACT.
 *
 * Seule page du site qui n'est pas une traversée : on n'y vient pas pour
 * regarder, on y vient pour écrire. Tout tient sur un écran, la caméra bouge à
 * peine, et la 3D se contente d'occuper la moitié droite laissée libre par le
 * formulaire.
 *
 * Les champs n'ont ni cadre ni fond : un libellé en mono et un filet horizontal
 * qui prend le vermillon quand le champ reçoit le focus. C'est la même logique
 * que le reste du site — le trait comme seul élément d'interface — et ça évite
 * les « boîtes » qui feraient basculer la page dans le formulaire administratif.
 */

const FIELDS = [
  { id: 'name', label: 'Nom complet', type: 'text', placeholder: 'Elon Musk', autoComplete: 'name' },
  {
    id: 'email',
    label: 'Email professionnel',
    type: 'email',
    placeholder: 'elon@tesla.com',
    autoComplete: 'email',
  },
];

export default function Contact() {
  const [sent, setSent] = useState(false);

  useScene({ depth: 10 });
  useEffect(() => bindScroll(), []);

  // Pas d'appel réseau : le site est front-only. Quand un vrai service prendra
  // le relais (Formspree, une API), garder ce même schéma — appeler dans
  // handleSubmit et ne passer `sent` à true qu'après une réponse valide, avec
  // un état d'erreur à ajouter ici même.
  const handleSubmit = (e) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <>


      <main className="run">
        <section className="station station--contact">
          <div className="contact">
            <div className="contact__intro veil">
              <p className="t-tag">Contact</p>
              <h1 className="t-title contact__title">
                Parlons de
                <br />
                votre <span className="t-soft flare">croissance</span>
              </h1>
              <p className="t-lead">
                Décrivez votre projet, je reviens vers vous sous 24 h ouvrées avec un premier retour
                concret.
              </p>

              <dl className="contact__facts">
                <div>
                  <dt className="t-tag">Email</dt>
                  <dd>
                    <a href="mailto:contact@example.com">contact@example.com</a>
                  </dd>
                </div>
                <div>
                  <dt className="t-tag">Zone</dt>
                  <dd>Basé en France — clients partout en Europe</dd>
                </div>
                <div>
                  <dt className="t-tag">Délai</dt>
                  <dd>Réponse sous 24 h ouvrées</dd>
                </div>
              </dl>
            </div>

            <div className="contact__panel">
              {sent ? (
                <div className="contact__done" role="status">
                  <p className="t-tag">Message envoyé</p>
                  <p className="contact__done-title">
                    Merci.
                    <br />
                    <span className="t-soft">Je reviens vers vous.</span>
                  </p>
                  <button type="button" className="act" onClick={() => setSent(false)}>
                    <span>Écrire un autre message</span>
                  </button>
                </div>
              ) : (
                <form className="form" onSubmit={handleSubmit}>
                  {FIELDS.map((field) => (
                    <div className="field" key={field.id}>
                      <label className="t-tag" htmlFor={field.id}>
                        {field.label}
                      </label>
                      <input
                        id={field.id}
                        name={field.id}
                        type={field.type}
                        placeholder={field.placeholder}
                        autoComplete={field.autoComplete}
                        required
                      />
                    </div>
                  ))}

                  <div className="field">
                    <label className="t-tag" htmlFor="message">
                      Votre projet
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      rows={5}
                      placeholder="Ce que vous cherchez à automatiser, et ce qui bloque aujourd’hui."
                      required
                    />
                  </div>

                  <button type="submit" className="act act--flare form__send">
                    <span>Envoyer la demande</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </section>
      </main>

      {/* Pas de compteur de progression : la page tient sur un écran, il
          resterait bloqué à 00 et n'informerait de rien. */}
      <Frame meter={false} />
    </>
  );
}
