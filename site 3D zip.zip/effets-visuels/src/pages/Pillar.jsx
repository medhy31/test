import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useScene } from '../three/sceneStore';
import { useVille } from '../three/villeContext';
import { bindScroll } from '../three/scrollStore';
import ArticleBody from '../components/ArticleBody';
import ArticleList from '../components/ArticleList';
import { extractHeadings } from '../content/markdown';
import Frame from '../components/Frame';
import {
  PILLAR,
  CLUSTERS,
  ARTICLES_BY_DATE,
  getArticlesByCategories,
} from '../content/articles';
import './Pillar.css';

/**
 * LE GUIDE — page pilier.
 *
 * Tête de l'arborescence éditoriale : elle couvre le sujet en entier et
 * redescend vers les trois branches et les quatre articles. C'est la page la
 * plus longue du site (18 min), et la seule à devoir jouer deux rôles à la
 * fois : un carrefour de navigation ET un texte suivi.
 *
 * D'où sa composition en deux temps. Le haut est un CARREFOUR — hero, puis les
 * trois branches en grandes tuiles qu'on ne peut pas manquer. Le bas est un
 * TEXTE — même dispositif que la page article : la scène s'arrête, le papier
 * prend le relais, sommaire à gauche.
 */

// Le sommaire suit la lecture. Même logique que sur la page article : on
// mémorise la visibilité de chaque titre plutôt que de réagir au seul événement
// reçu, sinon un défilement rapide laisse le sommaire bloqué sur la section
// précédente.
function useActiveHeading(headings) {
  const [activeId, setActiveId] = useState(headings[0]?.id ?? null);

  useEffect(() => {
    if (!headings.length) return undefined;
    const visible = new Map();

    const resolve = () => {
      const inBand = headings.find((h) => visible.get(h.id));
      if (inBand) {
        setActiveId(inBand.id);
        return;
      }
      const passed = headings.filter((h) => {
        const el = document.getElementById(h.id);
        return el && el.getBoundingClientRect().top < 140;
      });
      if (passed.length) setActiveId(passed[passed.length - 1].id);
    };

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => visible.set(e.target.id, e.isIntersecting));
        resolve();
      },
      { rootMargin: '-140px 0px -70% 0px', threshold: 0 },
    );

    headings
      .map((h) => document.getElementById(h.id))
      .filter(Boolean)
      .forEach((n) => observer.observe(n));

    return () => observer.disconnect();
  }, [headings]);

  return activeId;
}

export default function Pillar() {
  const { villeActive, setVilleActive } = useVille();
  const headings = useMemo(() => extractHeadings(PILLAR.content), []);
  const activeId = useActiveHeading(headings);

  // Scène « ville » : une tour par branche, cliquable (voir three/Ville.jsx).
  useScene({ depth: 24, scene: 'ville' });
  useEffect(() => bindScroll(), []);

  return (
    <>


      <main className="run guide">
        {/* ---------------------------------------------------- LE CARREFOUR */}
        <header className="guide__head veil">
          <Link to="/blog" className="guide__back t-tag">
            ← Retour au journal
          </Link>

          <p className="t-tag guide__kicker">
            <span className="flare">Guide</span>
          </p>

          <h1 className="t-display guide__title">
            Automatisation
            <br />
            <span className="t-soft">B2B</span>
          </h1>

          <p className="t-lead guide__lead">{PILLAR.subtitle}</p>

          <div className="guide__meta t-tag">
            <span>{PILLAR.readTime} min de lecture</span>
            <span>{headings.length} chapitres</span>
            <span>{ARTICLES_BY_DATE.length} articles satellites</span>
          </div>
        </header>

        {/* Les trois branches. Grandes tuiles et non liens de bas de page :
            c'est la fonction principale de cette page, elle doit se voir avant
            même de commencer à lire. */}
        <section className="station station--branches">
          <p className="t-tag station__tag">
            <span className="station__n">01</span>
            Les trois branches
          </p>

          <div className="branches">
            {CLUSTERS.map((cluster, i) => {
              const count = getArticlesByCategories(cluster.categories).length;
              return (
                <Link
                  key={cluster.slug}
                  to={cluster.slug}
                  className={`branch${villeActive === i ? ' is-on' : ''}`}
                  onMouseEnter={() => setVilleActive(i)}
                  onMouseLeave={() => setVilleActive(null)}
                >
                  <span className="branch__n t-tag">{String(i + 1).padStart(2, '0')}</span>
                  <h2 className="branch__title">
                    {cluster.title}
                    <br />
                    <span className="t-soft">{cluster.accent}</span>
                  </h2>
                  <p className="t-body branch__intro">{cluster.intro}</p>
                  <span className="branch__foot t-tag">
                    {count} article{count > 1 ? 's' : ''}
                    <span className="branch__go" aria-hidden="true">
                      →
                    </span>
                  </span>
                </Link>
              );
            })}
          </div>
        </section>

        {/* ---------------------------------------------------- LE TEXTE */}
        <div className="guide__body">
          <div className="guide__grid">
            <aside className="guide__toc" aria-label="Sommaire du guide">
              <p className="t-tag post__toc-title">Sommaire</p>
              <ol className="post__toc-list">
                {headings.map((h, i) => (
                  <li key={h.id}>
                    <a
                      href={`#${h.id}`}
                      className={h.id === activeId ? 'is-on' : ''}
                      aria-current={h.id === activeId ? 'true' : undefined}
                    >
                      <span className="post__toc-n">{String(i + 1).padStart(2, '0')}</span>
                      {h.text}
                    </a>
                  </li>
                ))}
              </ol>
            </aside>

            <article className="guide__text">
              <ArticleBody content={PILLAR.content} />
            </article>
          </div>

          {/* Les satellites : la moitié descendante du maillage. */}
          <section className="guide__satellites">
            <p className="t-tag station__tag">
              <span className="station__n">02</span>
              Les articles satellites
            </p>
            <ArticleList articles={ARTICLES_BY_DATE} />
          </section>

          <section className="guide__cta">
            <h2 className="t-title guide__cta-title">
              Besoin d&apos;aide pour
              <br />
              <span className="t-soft">mettre en place ?</span>
            </h2>
            <p className="t-body">
              Ce guide couvre la théorie. Mais la mise en place pratique ? C&apos;est mon expertise.
              Je peux construire un système d&apos;automatisation complet pour toi.
            </p>
            <Link to="/demarrer" className="act act--flare">
              <span>Décrire mon besoin</span>
            </Link>
          </section>
        </div>
      </main>

      <Frame />
    </>
  );
}
