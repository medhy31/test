import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Frame from '../components/Frame';
import ChoixBesoin from '../components/ChoixBesoin';
import { useScene } from '../three/sceneStore';
import { bindScroll } from '../three/scrollStore';
import { BESOINS, SOLUTIONS, PRECISIONS, LIVRABLES } from '../content/diagnostic';
import { envoyerDemande, EMAIL_SECOURS } from '../content/contact';
import './Start.css';

/**
 * QUALIFICATION DU BESOIN — le parcours de conversion.
 *
 * Quatre temps : le besoin, le contexte, la proposition, l'email. Chaque besoin
 * a sa proposition propre — c'est tout l'intérêt du dispositif : le visiteur
 * voit une réponse à SON cas avant qu'on lui demande quoi que ce soit.
 *
 * Pourquoi une étape à la fois plutôt qu'un long formulaire : un questionnaire
 * de sept champs affiché d'un bloc se lit comme un effort et se ferme. Ici la
 * première action est un simple clic sur une phrase qui décrit sa situation, et
 * l'email n'est demandé qu'en dernier, une fois la proposition affichée.
 */

const ETAPES = ['besoin', 'contexte', 'solution', 'contact'];

export default function Start() {
  // Un besoin peut arriver depuis la page d'accueil, où la première étape est
  // déjà posée. Dans ce cas on ouvre directement sur la suivante : refaire
  // choisir la même chose deux fois est le meilleur moyen de perdre la personne.
  const { state } = useLocation();
  const preChoix = state?.besoin ?? '';

  const [etape, setEtape] = useState(preChoix ? 'contexte' : 'besoin');
  const [reponses, setReponses] = useState({
    problem: preChoix,
    sector: '',
    volume: '',
    budget: '',
    email: '',
  });
  const [envoye, setEnvoye] = useState(false);
  // 'pret' | 'envoi' | 'echec'. L'échec n'est pas une erreur technique à
  // afficher : c'est une porte de sortie à proposer.
  const [etat, setEtat] = useState('pret');

  useScene({ depth: 12 });
  useEffect(() => bindScroll(), []);

  // Chaque changement d'étape remet en haut : les étapes n'ont pas la même
  // hauteur, et rester à mi-page fait atterrir au milieu de la suivante.
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [etape, envoye]);

  const maj = (champ, valeur) => setReponses((r) => ({ ...r, [champ]: valeur }));

  const contexteComplet = reponses.sector && reponses.volume && reponses.budget;
  const solution = SOLUTIONS[reponses.problem];
  const indexEtape = ETAPES.indexOf(etape);

  const retour = () => setEtape(ETAPES[Math.max(0, indexEtape - 1)]);

  // La destination vit dans content/contact.js. On ne bascule sur l'écran de
  // confirmation qu'après une réponse valide : afficher « c'est noté » alors que
  // rien n'est parti serait la pire issue possible — la personne repart
  // rassurée, et la demande n'existe nulle part.
  const envoyer = async (e) => {
    e.preventDefault();
    if (!reponses.email || etat === 'envoi') return;

    setEtat('envoi');
    const solution = SOLUTIONS[reponses.problem];
    const parti = await envoyerDemande({
      email: reponses.email,
      besoin: BESOINS.find((b) => b.id === reponses.problem)?.title ?? reponses.problem,
      secteur: reponses.sector,
      volume: reponses.volume,
      budget: reponses.budget,
      solution: solution?.title ?? '',
    });

    if (parti) {
      setEnvoye(true);
      setEtat('pret');
    } else {
      setEtat('echec');
    }
  };

  // Récapitulatif prêt à coller dans un mail, pour le cas où l'envoi échoue.
  const recapTexte = [
    `Besoin : ${BESOINS.find((b) => b.id === reponses.problem)?.title ?? ''}`,
    `Secteur : ${reponses.sector}`,
    `Volume : ${reponses.volume}`,
    `Budget : ${reponses.budget}`,
    `Email : ${reponses.email}`,
  ].join('\n');

  return (
    <>

      <main className="run">
        <section className="station station--start veil">
          <div className={`start${envoye ? ' start--done' : ''}`}>
            {!envoye && (
              <div className="start__rail">
                <p className="t-tag">
                  <span className="flare">{String(indexEtape + 1).padStart(2, '0')}</span> / 04
                </p>
                <ol className="start__steps t-tag">
                  {ETAPES.map((nom, i) => (
                    <li key={nom} className={i === indexEtape ? 'is-on' : i < indexEtape ? 'is-done' : ''}>
                      {nom}
                    </li>
                  ))}
                </ol>
              </div>
            )}

            {/* ------------------------------------------------ 01 BESOIN */}
            {!envoye && etape === 'besoin' && (
              <div className="start__panel">
                <h1 className="t-title start__title">
                  Quel est ton
                  <br />
                  <span className="t-soft flare">besoin ?</span>
                </h1>
                <p className="t-lead">Sélectionne celui qui te ressemble le plus.</p>

                <ChoixBesoin
                  onChoix={(id) => {
                    maj('problem', id);
                    setEtape('contexte');
                  }}
                />
              </div>
            )}

            {/* ---------------------------------------------- 02 CONTEXTE */}
            {!envoye && etape === 'contexte' && (
              <div className="start__panel">
                <h1 className="t-title start__title">
                  Quelques infos
                  <br />
                  pour <span className="t-soft flare">affiner</span>
                </h1>
                <p className="t-lead">Ça m&apos;aide à proposer la meilleure solution.</p>

                <div className="start__form">
                  {PRECISIONS.map((champ) => (
                    <div className="field" key={champ.id}>
                      <label className="t-tag" htmlFor={champ.id}>
                        {champ.label}
                      </label>
                      <select
                        id={champ.id}
                        value={reponses[champ.id]}
                        onChange={(e) => maj(champ.id, e.target.value)}
                      >
                        <option value="">Sélectionne…</option>
                        {champ.options.map((option) => (
                          <option key={option} value={option}>
                            {option}
                          </option>
                        ))}
                      </select>
                    </div>
                  ))}
                </div>

                <div className="start__actions">
                  <button type="button" className="act" onClick={retour}>
                    <span>← Retour</span>
                  </button>
                  <button
                    type="button"
                    className="act act--flare"
                    disabled={!contexteComplet}
                    onClick={() => setEtape('solution')}
                  >
                    <span>Continuer →</span>
                  </button>
                </div>
              </div>
            )}

            {/* ---------------------------------------------- 03 SOLUTION */}
            {!envoye && etape === 'solution' && solution && (
              <div className="start__panel">
                <p className="t-tag">Solution personnalisée</p>
                <h1 className="t-title start__title">{solution.title}</h1>
                <p className="t-lead">{solution.description}</p>

                <div className="resultat">
                  <p className="t-tag">Résultat attendu</p>
                  <p className="resultat__valeur">{solution.result}</p>
                </div>

                <div className="start__actions">
                  <button type="button" className="act" onClick={retour}>
                    <span>← Retour</span>
                  </button>
                  <button
                    type="button"
                    className="act act--flare"
                    onClick={() => setEtape('contact')}
                  >
                    <span>C&apos;est bon, je veux un devis</span>
                  </button>
                </div>
              </div>
            )}

            {/* ----------------------------------------------- 04 CONTACT */}
            {!envoye && etape === 'contact' && (
              <div className="start__panel">
                <h1 className="t-title start__title">
                  Laisse-moi
                  <br />
                  ton <span className="t-soft flare">email</span>
                </h1>
                <p className="t-lead">
                  Je vais te préparer un plan d&apos;action détaillé et un devis personnalisé.
                </p>

                <form className="start__form" onSubmit={envoyer}>
                  <div className="field">
                    <label className="t-tag" htmlFor="email">
                      Email professionnel
                    </label>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      autoComplete="email"
                      placeholder="elon@tesla.com"
                      value={reponses.email}
                      onChange={(e) => maj('email', e.target.value)}
                      required
                    />
                  </div>

                  {/* Récapitulatif : le visiteur a répondu à trois questions
                      plusieurs écrans plus tôt, il doit pouvoir vérifier ce
                      qu'il s'apprête à envoyer sans revenir en arrière. */}
                  <dl className="recap">
                    <div>
                      <dt className="t-tag">Besoin</dt>
                      <dd>{BESOINS.find((b) => b.id === reponses.problem)?.title}</dd>
                    </div>
                    <div>
                      <dt className="t-tag">Secteur</dt>
                      <dd>{reponses.sector}</dd>
                    </div>
                    <div>
                      <dt className="t-tag">Volume</dt>
                      <dd>{reponses.volume}</dd>
                    </div>
                    <div>
                      <dt className="t-tag">Budget</dt>
                      <dd>{reponses.budget}</dd>
                    </div>
                  </dl>

                  {/* Repli. Il n'apparaît qu'en cas d'échec réel : la personne
                      n'est jamais laissée devant un bouton mort, et la demande
                      n'est jamais perdue en silence. */}
                  {etat === 'echec' && (
                    <div className="echec" role="alert">
                      <p className="t-tag echec__titre">L&apos;envoi n&apos;a pas abouti</p>
                      <p className="t-body">
                        Le formulaire n&apos;a pas pu joindre le serveur. Écrivez-moi directement à{' '}
                        <a href={`mailto:${EMAIL_SECOURS}?subject=${encodeURIComponent('Demande de devis')}&body=${encodeURIComponent(recapTexte)}`}>
                          {EMAIL_SECOURS}
                        </a>{' '}
                        — vos réponses sont déjà reprises dans le message.
                      </p>
                    </div>
                  )}

                  <div className="start__actions">
                    <button type="button" className="act" onClick={retour}>
                      <span>← Retour</span>
                    </button>
                    <button type="submit" className="act act--flare" disabled={etat === 'envoi'}>
                      <span>{etat === 'envoi' ? 'Envoi…' : 'Demander mon devis'}</span>
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* -------------------------------------------------- SUCCÈS */}
            {envoye && (
              <div className="start__panel" role="status">
                <p className="t-tag">Demande enregistrée</p>
                <h1 className="t-title start__title">
                  C&apos;est
                  <br />
                  <span className="t-soft flare">noté !</span>
                </h1>
                <p className="t-lead">
                  Je vais analyser ton cas et te préparer un plan d&apos;action détaillé avec un
                  devis.
                </p>

                <div className="livrables">
                  <p className="t-tag">Tu vas recevoir</p>
                  <ul>
                    {LIVRABLES.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>

                <p className="t-body start__note">
                  Réponse sous 24 h. Vérifie tes spams au cas où.
                </p>

                <Link to="/" className="act">
                  <span>Retour à l&apos;accueil</span>
                </Link>
              </div>
            )}
          </div>
        </section>
      </main>

      <Frame meter={false} />
    </>
  );
}
