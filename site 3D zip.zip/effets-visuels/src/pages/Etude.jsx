import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import Frame from '../components/Frame';
import { useScene } from '../three/sceneStore';
import { bindScroll } from '../three/scrollStore';
import { ETUDE } from '../content/etude';
import './Etude.css';

/**
 * ÉTUDE DE CAS.
 *
 * La seule page du site qui prouve au lieu d'affirmer. Partout ailleurs les
 * chiffres reposent sur la parole ; ici chacun vient d'un journal d'exécution.
 *
 * Trois partis pris de composition qui découlent de cette fonction :
 *
 *  - le volume livré ouvre la page, parce qu'un prospect veut d'abord savoir ce
 *    qu'il obtient. La prouesse technique vient juste après, une fois qu'il a
 *    une raison de continuer à lire ;
 *
 *  - la page assume une section « ce qui a cassé ». Contre-intuitif sur une
 *    page commerciale, mais c'est elle qui rend le reste crédible : un
 *    prestataire qui n'a jamais rien cassé n'a jamais rien mis en production ;
 *
 *  - le passage « du script au système » est en deux colonnes, avant / après.
 *    C'est la forme qui montre le mieux une progression, et c'est ce qui vend
 *    une compétence — pas un volume.
 */
export default function Etude() {
  useScene({ depth: 26 });
  useEffect(() => bindScroll(), []);

  const { fait, etapes, taux, loi, incidents, livrable, leviers, socle, capacite } = ETUDE;

  return (
    <>
      <main className="run etude">
        {/* ---------------------------------------------------- OUVERTURE */}
        <header className="station station--etude veil">
          <div className="etude__tete">
            <p className="t-tag">{ETUDE.eyebrow}</p>
            <h1 className="t-display etude__titre">
              {ETUDE.titre}
              <br />
              <span className="t-soft">{ETUDE.accent}</span>
            </h1>
            <p className="t-lead">{ETUDE.resume}</p>
            {/* Le débit vient juste après le résumé : c'est la mesure qui
                transforme « il a livré une base » en « il a un système qui
                produit ». */}
            <p className="etude__capacite">
              {capacite.prefixe && (
                <span className="etude__capacite-prefixe">{capacite.prefixe}</span>
              )}
              <span className="etude__capacite-valeur">{capacite.valeur}</span>
              <span className="etude__capacite-label">{capacite.label}</span>
            </p>

            <dl className="etude__meta t-tag">
              <div>
                <dt>Client</dt>
                <dd>{ETUDE.client}</dd>
              </div>
              <div>
                <dt>Période</dt>
                <dd>{ETUDE.periode}</dd>
              </div>
            </dl>
          </div>
        </header>

        {/* ---------------------------------------------------- LE LIVRABLE */}
        <section className="station station--livrable veil">
          <p className="t-tag station__tag">
            <span className="station__n">01</span>
            {livrable.titre}
          </p>
          <p className="t-lead livrable__intro">{livrable.intro}</p>

          <div className="livrable">
            <ul className="livrable__liste">
              {livrable.donnees.map((d) => (
                <li key={d}>{d}</li>
              ))}
            </ul>

            <div className="taux">
              <p className="t-tag">Complétion par ligne</p>
              <ul>
                {taux.map((t) => (
                  <li key={t.label}>
                    <span className="taux__valeur">{t.valeur}</span>
                    <span className="taux__label">{t.label}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ------------------------------------------------------ LE FAIT */}
        <section className="station station--fait veil">
          <div className="fait">
            <p className="t-tag">Le point dur</p>
            <p className="fait__valeur">{fait.valeur}</p>
            <p className="fait__unite">{fait.unite}</p>
            <p className="fait__tenue">{fait.tenue}</p>
            <div className="fait__notes">
              <p className="t-body">{fait.contexte}</p>
              <p className="t-body">
                <strong>Pourquoi ça tient.</strong> {fait.pourquoi}
              </p>
            </div>
          </div>
        </section>

        {/* ---------------------------------------------------- LA MÉTHODE */}
        <section className="station station--etapes veil">
          <p className="t-tag station__tag">
            <span className="station__n">02</span>
            La méthode
          </p>
          <ol className="etapes">
            {etapes.map((e) => (
              <li key={e.n} className="etape">
                <span className="etape__n t-tag">{e.n}</span>
                <div>
                  <h2 className="etape__titre">{e.titre}</h2>
                  <p className="t-body">{e.texte}</p>
                </div>
              </li>
            ))}
          </ol>
        </section>

        {/* ---------------------------------------------------- LES LEVIERS */}
        <section className="station station--leviers veil">
          <p className="t-tag station__tag">
            <span className="station__n">03</span>
            {leviers.titre}
          </p>
          <div className="leviers">
            {leviers.liste.map((l) => (
              <article key={l.titre} className="levier">
                <h2 className="levier__titre">{l.titre}</h2>
                <p className="t-body">{l.texte}</p>
              </article>
            ))}
          </div>

          <div className="loi">
            <p className="t-tag">La règle qui gouverne tout le reste</p>
            <h2 className="t-title loi__titre">{loi.titre}</h2>
            <p className="t-body">{loi.texte}</p>
            <p className="t-body">{loi.consequence}</p>
          </div>
        </section>

        {/* ------------------------------------------------ L'INDUSTRIALISATION */}
        <section className="station station--socle veil">
          <p className="t-tag station__tag">
            <span className="station__n">04</span>
            {socle.titre}
          </p>
          <p className="t-lead socle__intro">{socle.intro}</p>

          <ol className="socle">
            {socle.lignes.map((l) => (
              <li key={l.apres} className="socle__ligne">
                <span className="socle__avant">{l.avant}</span>
                <span className="socle__fleche" aria-hidden="true">
                  →
                </span>
                <span className="socle__apres">{l.apres}</span>
              </li>
            ))}
          </ol>
        </section>

        {/* -------------------------------------------------- LES PANNES */}
        <section className="station station--pannes veil">
          <p className="t-tag station__tag">
            <span className="station__n">05</span>
            {incidents.titre}
          </p>
          <p className="t-lead pannes__intro">{incidents.intro}</p>

          <ul className="pannes">
            {incidents.liste.map((i) => (
              <li key={i.quoi} className="panne">
                <div className="panne__tete">
                  <h3 className="panne__quoi">{i.quoi}</h3>
                  <span className="panne__cout t-tag">{i.cout}</span>
                </div>
                <p className="t-body">{i.lecon}</p>
              </li>
            ))}
          </ul>
        </section>

        {/* ----------------------------------------------------------- CTA */}
        <section className="station station--end">
          <div className="station__inner">
            <h2 className="t-title">
              Le même travail,
              <br />
              <span className="t-soft">sur votre marché ?</span>
            </h2>
            <Link to="/demarrer" className="act act--flare">
              <span>Décrire mon besoin</span>
            </Link>
          </div>
        </section>
      </main>

      <Frame />
    </>
  );
}
