// Qualification du besoin — contenu repris VERBATIM du site en production
// (client/src/components/DiagnosticForm.tsx), récupéré dans le bundle JS.
//
// Le parcours en quatre temps : on choisit un besoin, on précise le contexte,
// on reçoit une proposition correspondante, on laisse son email. Chaque besoin
// a SA solution : c'est tout l'intérêt du dispositif, le visiteur voit une
// réponse à son cas et non une plaquette générique.

export const BESOINS = [
  {
    id: 'data-extraction',
    title: 'Extraire des données',
    description: "J'ai besoin de scraper des données depuis des sources web",
  },
  {
    id: 'workflow-automation',
    title: 'Automatiser mes workflows',
    description: 'Connecter mes outils et éliminer les tâches manuelles',
  },
  {
    id: 'crm-integration',
    title: 'Intégrer mes outils',
    description: 'Synchroniser mes données entre plusieurs plateformes',
  },
  {
    id: 'custom-solution',
    title: 'Besoin custom',
    description: 'Un système ou script sur-mesure pour mon besoin spécifique',
  },
  {
    id: 'data-pipeline',
    title: 'Data center / Pipeline',
    description: 'Traiter et analyser de grandes quantités de données',
  },
  {
    id: 'reporting',
    title: 'Dashboards & Reporting',
    description: 'Automatiser mes rapports et créer des dashboards',
  },
];

export const SOLUTIONS = {
  'data-extraction': {
    title: 'Système de Scraping Automatisé',
    description:
      'Je vais construire un scraper robuste et scalable pour extraire tes données. Nettoyage, déduplication et structuration inclus.',
    result: "Données extraites et prêtes à l'emploi",
  },
  'workflow-automation': {
    title: 'Pipeline Automatisé Complet',
    description:
      'Je vais créer un workflow qui connecte tes outils et élimine les tâches répétitives. Make, n8n ou Python selon tes besoins.',
    result: 'Économies de 10-20h de travail par semaine',
  },
  'crm-integration': {
    title: 'Intégration Multi-Outils',
    description:
      'Je vais synchroniser tes données entre tous tes outils. HubSpot, Pipedrive, Airtable, Slack — tout connecté en temps réel.',
    result: 'Zéro perte de données, synchronisation automatique',
  },
  'custom-solution': {
    title: 'Solution Sur-Mesure',
    description:
      "Je vais construire exactement ce dont tu as besoin. Script Python, API custom, logique métier complexe — sur-mesure pour toi.",
    result: 'Système adapté à 100% à ton besoin',
  },
  'data-pipeline': {
    title: 'Data Center & Pipeline',
    description:
      'Je vais construire un système robuste de traitement de données. ETL, data warehousing, pipelines scalables pour gérer de gros volumes.',
    result: 'Infrastructure de données performante et scalable',
  },
  reporting: {
    title: 'Dashboards & Reporting Automatisé',
    description:
      'Je vais créer des dashboards en temps réel et automatiser tes rapports. Chaque jour, semaine ou mois, tes rapports se génèrent tout seuls.',
    result: 'Rapports automatisés, dashboards en temps réel',
  },
};

// Les trois précisions de la deuxième étape. Toutes obligatoires : c'est ce qui
// permet de proposer un montant, et un formulaire de trois champs qu'on peut
// sauter ne qualifie rien.
export const PRECISIONS = [
  {
    id: 'sector',
    label: "Ton secteur d'activité",
    options: ['SaaS', 'E-commerce', 'Agence digitale', 'Cabinet de conseil', 'Fintech', 'Autre'],
  },
  {
    id: 'volume',
    label: 'Volume de données / Complexité',
    options: [
      'Petit (moins de 1K données/jour)',
      'Moyen (1K - 100K données/jour)',
      'Grand (plus de 100K données/jour)',
      'Très complexe (logique métier avancée)',
    ],
  },
  {
    id: 'budget',
    label: 'Budget estimé',
    options: ['500-1000€', '1000-5000€', '5000-15000€', '15000€+'],
  },
];

export const LIVRABLES = [
  'Un diagnostic complet de ta situation',
  'Un plan d’action étape par étape',
  'Un devis transparent et détaillé',
];
