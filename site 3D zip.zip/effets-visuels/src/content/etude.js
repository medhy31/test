// Étude de cas — anonymisée.
//
// Projet national de constitution d'une base de prospection à partir du
// registre officiel des entreprises françaises. Le client n'est jamais nommé,
// ni les branches professionnelles ciblées : elles suffiraient à l'identifier.
//
// Les chiffres viennent des journaux d'exécution et du code du pipeline, pas
// d'une estimation. C'est la seule raison pour laquelle cette page a de la
// valeur — n'y ajouter aucun chiffre qui n'aurait pas été mesuré.

export const ETUDE = {
  eyebrow: 'Étude de cas',
  titre: '120 000',
  accent: 'leads qualifiés,\nla France entière',
  client: "Organisme d'accompagnement en formation et recrutement",
  periode: 'Mars → août 2026',
  resume:
    "Construire une base de prospection nationale à partir du registre officiel des entreprises, l'enrichir automatiquement en contacts directs, et la maintenir à jour sans jamais se faire bloquer.",

  // Débit annoncé en CAPACITÉ, pas en mesure — la nuance compte si on nous
  // demande les journaux. Les journées pleines observées tournent autour de
  // 20 000 lignes ; 25 000 est ce que l'architecture soutient dès qu'on ajoute
  // des adresses IP, chacune portant 2 000 à 5 000 lignes par jour (voir la
  // règle d'échelle plus bas). Écrire « jusqu'à » plutôt qu'un chiffre sec.
  capacite: {
    valeur: '25 000',
    prefixe: 'jusqu’à',
    label: 'lignes enrichies par jour',
  },

  // Ce que le client reçoit. Placé avant la technique : un prospect veut
  // d'abord savoir ce qu'il obtient, pas comment on l'obtient.
  livrable: {
    titre: 'Ce que contient chaque ligne',
    intro:
      "Le fichier n'est pas une liste d'entreprises : c'est un fichier de travail commercial, livré dans le format du client, colonnes de suivi comprises.",
    donnees: [
      'Nom du dirigeant',
      'Téléphone direct',
      'Email professionnel',
      'Raison sociale et SIRET',
      'Branche professionnelle de rattachement',
      'Colonnes de suivi : relance, statut, commentaires',
    ],
  },

  taux: [
    { valeur: '77 %', label: 'téléphone trouvé' },
    { valeur: '75 %', label: 'nom du dirigeant identifié' },
    { valeur: '33 %', label: 'email professionnel trouvé' },
  ],

  // Le point dur. Ce n'est pas le chiffre le plus flatteur, c'est celui que
  // personne ne peut revendiquer sans l'avoir fait.
  fait: {
    valeur: '2 300',
    unite: 'requêtes Google Maps par jour, sur une seule adresse IP',
    tenue: '48 heures d’affilée, sans blocage',
    contexte:
      'La documentation technique de 2026 situe le seuil de blocage entre 30 et 100 requêtes par jour et par IP, et quasi immédiat depuis une IP de datacenter. Le pipeline a tenu 20 à 70 fois au-dessus.',
    pourquoi:
      'Parce qu’il passe par un vrai navigateur Chrome — écran de consentement géré, délais naturels — et non par un client HTTP qui se signale à chaque requête.',
  },

  etapes: [
    {
      n: '01',
      titre: 'Partir du registre officiel',
      texte:
        "Pas d'annuaire acheté : la base publique des établissements français, 2,37 millions de lignes, croisée avec les conventions collectives pour rattacher chaque entreprise à sa branche professionnelle. Une jointure locale, sans quota ni plafond d'API.",
    },
    {
      n: '02',
      titre: 'Filtrer sur des signaux, pas sur des codes',
      texte:
        "Un code d'activité ne dit pas si une entreprise a un besoin aujourd'hui. Le ciblage s'appuie sur des signaux concrets — croissance des effectifs, postes ouverts, implantations récentes : une entreprise qui recrute est réceptive, une entreprise qui stagne ne l'est pas.",
    },
    {
      n: '03',
      titre: 'Enrichir sans se faire bannir',
      texte:
        "Chaque ligne retenue passe par une chaîne d'enrichissement : dirigeant, téléphone, site, email. C'est l'étape qui casse tous les projets de collecte, parce qu'elle demande d'interroger des sources qui se défendent.",
    },
    {
      n: '04',
      titre: 'Livrer dans l’outil du client',
      texte:
        "Une base qui demande un travail de reprise avant import n'est pas livrée. Le fichier sort directement dans le format de travail du client, prêt à être exploité par son équipe commerciale.",
    },
  ],

  // Les deux décisions qui ont changé l'ordre de grandeur. C'est le passage qui
  // distingue quelqu'un qui a lu des articles de quelqu'un qui a fait tourner
  // le système en production.
  leviers: {
    titre: 'Deux décisions qui ont divisé le temps de collecte',
    liste: [
      {
        titre: 'Interroger par pages de 25, pas ligne par ligne',
        texte:
          "Le registre hors ligne ne donne le nom du dirigeant que pour 4,5 % du périmètre. L'API officielle le fournit pour environ 75 % — mais une requête par entreprise, c'est 130 000 appels. En interrogeant par pages de 25, il en faut 5 500. Vingt-quatre fois moins, pour la même donnée.",
      },
      {
        titre: 'N’appeler la source surveillée qu’en dernier recours',
        texte:
          "Google n'est sollicité que lorsque les sources ouvertes échouent, ou pour arbitrer un doute. Le budget par adresse IP passe de 2 000 à 5 000 lignes par jour — la France entière en trois semaines, sur une seule adresse.",
      },
    ],
  },

  loi: {
    titre: 'La vitesse s’achète en adresses IP, pas en processus',
    texte:
      "Le mur du passage à l'échelle n'est pas Google : c'est le nombre d'adresses IP disponibles. Chaque IP tient un volume donné par jour, quel que soit le nombre de processus lancés dessus. Mettre seize processus sur une seule adresse ne va pas cinq fois plus vite — ça se fait bannir cinq fois plus vite.",
    consequence:
      "Le dimensionnement machine découle de l'IP, il ne la précède pas : 2 000 lignes par jour, c'est environ trois sessions de navigateur simultanées, soit un petit serveur à deux cœurs par adresse. Le reste est du gaspillage.",
  },

  // L'industrialisation : ce qui distingue un script qui marche une fois d'un
  // système qui tourne tout seul.
  socle: {
    titre: 'Du script au système',
    intro:
      "Un pipeline qui produit une fois n'a aucune valeur : ce qui compte, c'est celui qui tourne sans surveillance et qui redémarre seul. Voici ce qui a changé entre la première campagne et la version de production.",
    lignes: [
      { avant: '425 appels d’API segmentés par département', apres: 'Une jointure locale, sans quota ni plafond' },
      { avant: 'Un tableur comme base de travail', apres: 'Une base de données comme source de vérité' },
      { avant: 'Boucle artisanale et compteur tenu à la main', apres: 'File de travail avec reprise automatique après incident' },
      { avant: 'Rythme subi, aucun garde-fou', apres: 'Quota explicite par adresse IP, jamais dépassé' },
      { avant: 'Panne découverte quatre jours plus tard', apres: 'Alerte au bout de trente minutes' },
      { avant: 'Tourne sur un poste de travail', apres: 'Service serveur, sauvegarde et surveillance automatiques' },
      { avant: 'Quelques centaines de lignes par jour', apres: 'Des dizaines de milliers par jour, sans surveillance' },
    ],
  },

  // La section qui rend la page crédible. Un prestataire qui n'a jamais rien
  // cassé n'a jamais rien mis en production.
  incidents: {
    titre: 'Ce qui a cassé',
    intro:
      "Aucun système de collecte ne tourne à 100 %. Voici ce qui est réellement tombé pendant la campagne, ce que ça a coûté, et ce que ça a fait changer — c'est exactement ce qui a servi à dimensionner la version de production.",
    liste: [
      {
        quoi: 'Jeton d’authentification expiré',
        cout: '4 jours de pipeline à l’arrêt',
        lecon:
          "L'incident le plus coûteux du projet n'était pas technique, il était silencieux : rien n'alertait. C'est de là que vient la surveillance à trente minutes.",
      },
      {
        quoi: 'Verrou de traitement bloqué par un fil mort',
        cout: '≈ 10 heures',
        lecon: 'Un chien de garde redémarre désormais le service au-delà d’un délai sans progression.',
      },
      {
        quoi: 'Mémoire épuisée sur une exécution monolithique',
        cout: 'Un traitement national perdu',
        lecon:
          "Les lots sont plafonnés et l'écriture se fait au fil de l'eau : un incident ne coûte plus que le lot en cours.",
      },
      {
        quoi: 'Pare-feu applicatif des sites cibles',
        cout: '362 refus en 48 h',
        lecon:
          "C'est ce qui plafonne le taux d'emails à un tiers. Une seule passe par domaine, trois pages au maximum : insister ferait perdre le domaine définitivement.",
      },
    ],
  },
};
