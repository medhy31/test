// Gwen — Contenu éditorial du blog, source unique de vérité.
//
// Repris VERBATIM du site en production (leadgenrom-b5lr9xte.manus.space), dont
// le contenu vivait uniquement dans le bundle JS (SPA sans rendu serveur). Ne
// réécris pas ces textes : ils sont indexés et maillés entre eux. Pour publier,
// ajoute une entrée en respectant la forme ci-dessous.
//
// Note sur les métadonnées : le site source se contredisait entre son index et
// ses pages de détail (catégories et temps de lecture différents pour un même
// article). On retient partout la version des pages de détail — c'est la version
// longue, sourcée et maillée. Les écarts sont notés article par article.

export const PILLAR = {
  title: "Guide Complet de l'Automatisation B2B",
  url: '/guide-automatisation-b2b',
  subtitle:
    'Tout ce que tu dois savoir pour automatiser tes processus B2B et économiser 15h/semaine',
  readTime: 18,
  // Le guide est la page pilier de l'arborescence SEO : il couvre le sujet en
  // entier et renvoie vers chaque article satellite. Contenu verbatim du site
  // source (client/src/pages/PillarPage.tsx).
  content: `# Guide Complet de l'Automatisation B2B : De la Théorie à la Pratique

## Introduction

L'automatisation B2B est devenue **essentielle** pour rester compétitif. Les entreprises qui automatisent leurs processus économisent en moyenne **15 heures par semaine** et augmentent leur productivité de **40%**.

Mais par où commencer ? Cet article couvre **tout ce que tu dois savoir** sur l'automatisation B2B : les concepts, les outils, les cas d'usage et les stratégies pour mettre en place.

---

## 1. Qu'est-ce que l'automatisation B2B ?

L'automatisation B2B consiste à **automatiser les processus métier** entre entreprises. Au lieu de faire manuellement les mêmes tâches répétitives, tu crées des workflows qui tournent 24/7.

### Exemples d'automatisation B2B :
- **Prospection** : Scraper des leads, enrichir les données, envoyer des emails automatiquement
- **CRM** : Créer des contacts automatiquement, envoyer des relances, mettre à jour les statuts
- **Facturation** : Générer des factures, envoyer des rappels de paiement, mettre à jour la comptabilité
- **Onboarding** : Créer des comptes, envoyer des emails de bienvenue, assigner des tâches
- **Reporting** : Collecter les données, générer des rapports, envoyer les résultats

### Avantages de l'automatisation B2B :
- ✅ **Économie de temps** : 10-20 heures/semaine économisées
- ✅ **Réduction des erreurs** : Pas d'erreurs manuelles
- ✅ **Augmentation de la productivité** : Faire plus avec moins de ressources
- ✅ **Meilleure expérience client** : Réponses plus rapides
- ✅ **ROI rapide** : Rentabilisé en 2-3 mois

---

## 2. Les 5 piliers de l'automatisation B2B

### 2.1 Scraping et Extraction de Données

Le scraping est l'étape 1 de toute automatisation. Tu extrais les données brutes depuis n'importe quelle source.

**Sources courantes :**
- LinkedIn (profils, entreprises)
- Google Maps (entreprises locales)
- Annuaires professionnels
- Sites web concurrents
- Bases de données publiques

**Outils :** Apify, PhantomBuster, Python + Selenium

**Lire aussi :** [Comment scraper LinkedIn sans se faire bloquer](/blog/linkedin-scraping)

### 2.2 Enrichissement de Données

Une simple liste d'emails n'a aucune valeur. L'enrichissement transforme une liste basique en **base de prospection complète**.

**Données à enrichir :**
- Email vérifié
- Poste et entreprise
- Téléphone direct
- Profil LinkedIn
- Secteur et taille de l'entreprise

**Outils :** Hunter.io, RocketReach, Clearbit

**Lire aussi :** [Enrichissement de leads : La vraie stratégie](/blog/lead-enrichment)

### 2.3 Segmentation et Qualification

Tous les leads ne sont pas égaux. La segmentation permet de **cibler les bons prospects**.

**Critères de segmentation :**
- Secteur d'activité
- Taille de l'entreprise
- Poste décisionnaire
- Budget estimé
- Localisation

**Outils :** CRM, Airtable, Google Sheets + formules

### 2.4 Workflows Automatisés

Les workflows sont le **cœur de l'automatisation**. Ils connectent tes outils et exécutent des actions en cascade.

**Exemple de workflow :**
1. Un nouveau lead arrive dans ta base
2. Hunter.io vérifie l'email
3. RocketReach enrichit les données
4. Le lead est ajouté au CRM
5. Un email de bienvenue est envoyé
6. Une tâche est créée pour l'équipe
7. Une notification Slack est envoyée

**Outils :** Make.com, n8n, Zapier

**Lire aussi :** [Automatiser ton CRM avec Make en 30 minutes](/blog/make-automation)

### 2.5 Prospection Multicanal

La prospection ne se limite plus à l'email. Les meilleures résultats viennent de la **combinaison de plusieurs canaux**.

**Canaux :**
- Email (cold email, newsletters)
- LinkedIn (messages, connexions)
- SMS (messages texte)
- Appels (avec numéros de téléphone)
- Réseaux sociaux (commentaires, messages)

**Outils :** Mailchimp, Brevo, LinkedIn Sales Navigator

---

## 3. Les Outils Essentiels pour l'Automatisation B2B

### Scraping et Données
- **Apify** : Scrapers pré-construits pour LinkedIn, Google Maps, etc.
- **PhantomBuster** : Scraping LinkedIn et autres réseaux sociaux
- **Python + Selenium** : Solution personnalisée pour du scraping avancé

### Enrichissement
- **Hunter.io** : Vérification et enrichissement d'emails
- **RocketReach** : Données complètes (email, téléphone, poste)
- **Clearbit** : API d'enrichissement en temps réel

### Automatisation
- **Make.com** : Plateforme d'automatisation sans code (meilleur rapport qualité-prix)
- **n8n** : Open source, plus puissant mais plus technique
- **Zapier** : Plus simple mais plus cher

### CRM et Gestion des Leads
- **HubSpot** : CRM complet avec automatisation
- **Pipedrive** : CRM axé sur la vente
- **Airtable** : Base de données flexible

### Prospection Email
- **Brevo** : Email marketing avec automatisation
- **Mailchimp** : Email marketing simple
- **Lemlist** : Cold email avec personnalisation

---

## 4. Cas d'Usage Réels d'Automatisation B2B

### Cas 1 : Agence SaaS (150 leads/semaine)

**Problème :** Prospection manuelle qui prend 20h/semaine

**Solution :**
1. Scraper LinkedIn pour trouver des prospects (Make + Apify)
2. Enrichir les données avec Hunter.io
3. Envoyer des emails personnalisés avec Lemlist
4. Ajouter les réponses au CRM automatiquement
5. Créer des tâches pour l'équipe de vente

**Résultats :**
- ✅ 150 leads/semaine (vs 50 avant)
- ✅ 15h économisées/semaine
- ✅ Taux de réponse : 12% (vs 3% avant)

### Cas 2 : Cabinet de Conseil (Enrichissement de base)

**Problème :** Base de 5000 contacts incomplète

**Solution :**
1. Exporter la base
2. Enrichir avec RocketReach et Clearbit
3. Dédupliquer et nettoyer
4. Importer dans le CRM

**Résultats :**
- ✅ 85% des contacts enrichis
- ✅ Emails vérifiés à 95%
- ✅ Données à jour et complètes

### Cas 3 : E-commerce B2B (Automatisation Multicanal)

**Problème :** Leads perdus, pas de suivi automatique

**Solution :**
1. Lead arrive → Email auto + SMS + LinkedIn message
2. Email ouvert → Relance automatique
3. Pas de réponse après 5 jours → Appel manuel
4. Contrat signé → Facture auto + Onboarding auto

**Résultats :**
- ✅ Taux de conversion : +45%
- ✅ Cycle de vente réduit de 30%
- ✅ Satisfaction client : +60%

---

## 5. Comment Mettre en Place l'Automatisation B2B

### Étape 1 : Audit (1-2 jours)
- Identifier les processus répétitifs
- Mesurer le temps perdu
- Définir les objectifs

### Étape 2 : Conception (3-5 jours)
- Dessiner les workflows
- Choisir les outils
- Planifier l'intégration

### Étape 3 : Mise en Place (1-2 semaines)
- Configurer les outils
- Créer les workflows
- Tester en petit volume

### Étape 4 : Lancement (1 semaine)
- Lancer progressivement
- Monitorer les résultats
- Ajuster en temps réel

### Étape 5 : Optimisation (Continu)
- Analyser les données
- Améliorer les workflows
- Ajouter de nouveaux canaux

---

## 6. Les Erreurs à Éviter

1. ❌ **Automatiser trop vite** → Vérifier d'abord que le processus fonctionne manuellement
2. ❌ **Ignorer la qualité des données** → Des données pourries = des résultats pourris
3. ❌ **Ne pas tester** → Toujours tester en petit volume avant de lancer
4. ❌ **Oublier la compliance** → Respecter la GDPR et les ToS des outils
5. ❌ **Négliger le suivi** → Monitorer constamment les résultats

---

## 7. Conclusion : L'Automatisation B2B est l'Avenir

L'automatisation B2B n'est plus une option. C'est une **nécessité** pour rester compétitif.

Les entreprises qui automatisent :
- ✅ Économisent 10-20 heures/semaine
- ✅ Augmentent leur productivité de 40%+
- ✅ Réduisent les erreurs de 90%
- ✅ Améliorent la satisfaction client

**Prêt à automatiser ?** Je peux mettre en place un système complet pour toi.

---

## Ressources Supplémentaires

- [Comment scraper LinkedIn sans se faire bloquer](/blog/linkedin-scraping)
- [Automatiser ton CRM avec Make en 30 minutes](/blog/make-automation)
- [Enrichissement de leads : La vraie stratégie](/blog/lead-enrichment)
- [Les 5 erreurs à éviter en data extraction](/blog/data-extraction-errors)`,
};

// Les 4 catégories du blog. L'ordre fait foi pour l'affichage des filtres.
export const CATEGORIES = ['Scraping', 'Automatisation', 'Data', 'Leads'];

// Clusters SEO : chaque page cluster agrège les articles de ses catégories et
// remonte vers la page pilier (maillage interne, ne pas casser).
export const CLUSTERS = [
  {
    slug: '/scraping-linkedin',
    label: 'Scraping LinkedIn',
    title: 'Extraire la donnée',
    accent: 'sans se faire bloquer.',
    intro:
      "Sourcer des prospects à la main ne passe pas l'échelle. Voici comment extraire des données LinkedIn et web de façon fiable, légale et reproductible.",
    categories: ['Scraping'],
  },
  {
    slug: '/automation-workflows',
    label: "Workflows d'automatisation",
    title: 'Connecter vos outils',
    accent: "sans écrire de code.",
    intro:
      'Un CRM qui se remplit seul, des relances qui partent seules, une équipe prévenue au bon moment. Les workflows qui font tourner la machine.',
    categories: ['Automatisation'],
  },
  {
    slug: '/generation-leads',
    label: 'Génération de leads',
    title: 'Transformer la donnée',
    accent: 'en pipeline.',
    intro:
      "Une liste d'emails ne vaut rien. Une base enrichie, vérifiée et qualifiée vaut un trimestre de prospection. La différence se joue ici.",
    categories: ['Data', 'Leads'],
  },
];

export const ARTICLES = [
  {
    id: "linkedin-scraping",
    title: "Comment scraper LinkedIn sans se faire bloquer",
    excerpt:
      "Les 5 techniques éprouvées pour extraire des données LinkedIn en masse sans déclencher les alertes de sécurité.",
    date: "2026-07-03",
    readTime: 12, // écart source — index : 8 min
    category: "Scraping",
    author: "Romain",
    sources: [
      { title: "LinkedIn Sales Navigator Official", url: "https://business.linkedin.com/en-us/sales-solutions/sales-navigator" },
      { title: "Apify LinkedIn Scraper", url: "https://apify.com/apify/linkedin-scraper" },
      { title: "PhantomBuster LinkedIn Tools", url: "https://phantombuster.com/linkedin-tools" },
      { title: "Selenium Documentation", url: "https://www.selenium.dev/" },
    ],
    relatedPillar: PILLAR,
    content: `# Comment scraper LinkedIn sans se faire bloquer

Scraper LinkedIn, c'est l'une des meilleures façons de générer des **leads B2B qualifiés**. Mais attention : LinkedIn protège ses données férocement. Beaucoup de freelances et d'agences se font bloquer après quelques jours de scraping agressif.

La bonne nouvelle ? Il existe des techniques éprouvées pour extraire des données LinkedIn **sans déclencher les alertes de sécurité**. Dans cet article, je te partage les 5 méthodes que j'utilise avec mes clients.

## 1. Utiliser LinkedIn Sales Navigator (La méthode officielle)

[LinkedIn Sales Navigator](https://business.linkedin.com/en-us/sales-solutions/sales-navigator) est l'outil officiel de LinkedIn pour la prospection. C'est la **méthode la plus sûre** et la plus légale.

**Comment ça marche :**
- Tu crées une liste de prospects selon des critères (secteur, poste, localisation)
- Tu extrais les données manuellement ou via une API
- Aucun risque de blocage car c'est approuvé par LinkedIn

**Avantages :**
- ✅ Légal et approuvé par LinkedIn
- ✅ Données à jour et vérifiées
- ✅ Pas de risque de blocage
- ✅ Intégration facile avec les CRM

**Inconvénients :**
- ❌ Coûteux (99€/mois minimum)
- ❌ Limite de 500 leads/mois
- ❌ Pas d'automatisation complète

## 2. Utiliser des outils de scraping autorisés

Des outils comme **[Apify](https://apify.com/apify/linkedin-scraper)** et **[PhantomBuster](https://phantombuster.com/linkedin-tools)** offrent des scrapers LinkedIn légaux et sûrs.

**Avantages :**
- ✅ Légal (respecte les ToS de LinkedIn)
- ✅ Automatisé
- ✅ Pas de risque de blocage
- ✅ Support technique inclus

## 3. Scraping Python avec gestion des proxies (Avancé)

Si tu veux du scraping à grande échelle, Python + proxies est la solution. Utilise des bibliothèques comme BeautifulSoup ou Scrapy avec rotation de proxies.

## 4. Utiliser Selenium avec des délais aléatoires

[Selenium](https://www.selenium.dev/) simule un vrai navigateur, ce qui réduit le risque de détection. Ajoute des délais aléatoires entre les actions pour éviter les patterns.

## 5. Combiner plusieurs techniques (La méthode hybride)

La meilleure approche ? **Combiner plusieurs méthodes** :

1. **LinkedIn Sales Navigator** pour les leads premium
2. **Apify** pour les extractions automatisées
3. **Python + proxies** pour les gros volumes
4. **Enrichissement manuel** pour les données sensibles

## Les 5 erreurs à éviter absolument

1. ❌ **Scraper trop vite** → LinkedIn détecte les patterns
2. ❌ **Utiliser le même User-Agent** → Trop facile à détecter
3. ❌ **Ne pas utiliser de proxies** → Ton IP se fait bloquer
4. ❌ **Scraper 24/7** → LinkedIn bloque les bots
5. ❌ **Ignorer les ToS** → Risque de ban permanent

## Conclusion

Scraper LinkedIn, c'est possible **sans se faire bloquer**. La clé ? Être intelligent, utiliser les bons outils, et respecter les limites de LinkedIn.

Si tu veux une solution clé en main (sans te casser la tête avec le code), je peux te mettre en place un système de scraping automatisé qui respecte les règles. Zéro blocage, zéro risque.

**Cet article fait partie du [Guide Complet de l'Automatisation B2B](/guide-automatisation-b2b), qui couvre tous les aspects de l'automatisation.**`,
  },
  {
    id: "make-automation",
    title: "Automatiser ton CRM avec Make en 30 minutes",
    excerpt:
      "Connecte ton CRM, email et Slack en 30 minutes sans code. Guide complet avec screenshots.",
    date: "2026-07-02",
    readTime: 10, // écart source — index : 6 min
    category: "Automatisation",
    author: "Romain",
    sources: [
      { title: "Make.com Official", url: "https://www.make.com/" },
      { title: "Make.com Documentation", url: "https://www.make.com/en/help" },
      { title: "Zapier Alternatives", url: "https://zapier.com/" },
      { title: "n8n Open Source Automation", url: "https://n8n.io/" },
    ],
    relatedPillar: PILLAR,
    content: `# Automatiser ton CRM avec Make en 30 minutes

Ton CRM est un désert. Les leads arrivent mais personne ne les suit. Les emails ne s'envoient pas automatiquement. Les équipes ne reçoivent pas d'alertes.

**Résultat :** Des leads perdus, des opportunités manquées, du temps gaspillé.

La bonne nouvelle ? Tu peux **automatiser tout ça en 30 minutes** avec [Make.com](https://www.make.com/). Pas besoin de code. Juste du drag-and-drop.

## Qu'est-ce que Make.com ?

[Make.com](https://www.make.com/) (anciennement Integromat) est une plateforme d'**automatisation sans code** qui connecte tes outils.

**Exemple simple :**
- Un lead arrive dans ta base de données
- Make envoie automatiquement un email
- Make crée une tâche dans ton CRM
- Make envoie une notification Slack à l'équipe

Tout ça en 2 minutes de configuration.

## 5 Workflows à mettre en place ASAP

1. **Nouveau lead → Email auto + CRM** 
2. **Lead qualifié → Slack notification + Calendly**
3. **Email ouvert → Update CRM + Follow-up auto**
4. **Contrat signé → Invoice + Confirmation email**
5. **Inactivité 30 jours → Re-engagement email**

## Comment démarrer avec Make

1. Crée un compte sur [Make.com](https://www.make.com/)
2. Connecte ton CRM (HubSpot, Pipedrive, Airtable, etc.)
3. Crée un workflow simple (5 minutes)
4. Teste et lance

Consulte la [documentation Make](https://www.make.com/en/help) pour les détails.

## Alternatives : Zapier et n8n

- **[Zapier](https://zapier.com/)** : Plus simple mais plus cher
- **[n8n](https://n8n.io/)** : Open source, plus puissant mais plus technique

## Conclusion

Make est le meilleur rapport qualité-prix pour l'automatisation CRM. En 30 minutes, tu peux économiser 10 heures/semaine.

**Cet article fait partie du [Guide Complet de l'Automatisation B2B](/guide-automatisation-b2b), qui couvre tous les aspects de l'automatisation.**`,
  },
  {
    id: "data-extraction-errors",
    title: "Les 5 erreurs à éviter en data extraction",
    excerpt:
      "Découvrez les 5 erreurs les plus courantes en scraping et data extraction. Et comment les éviter.",
    date: "2026-07-01",
    readTime: 8, // écart source — index : catégorie « Scraping », 7 min
    category: "Data",
    author: "Romain",
    sources: [
      { title: "GDPR Compliance Guide", url: "https://gdpr-info.eu/" },
      { title: "Web Scraping Legal Guide", url: "https://blog.apify.com/is-web-scraping-legal/" },
      { title: "Data Quality Best Practices", url: "https://www.gartner.com/en/information-technology/insights/data-quality" },
      { title: "Email Verification Tools", url: "https://www.hunter.io/" },
    ],
    relatedPillar: PILLAR,
    content: `# Les 5 erreurs à éviter en data extraction

L'extraction de données est une compétence cruciale pour la prospection B2B. Mais beaucoup de freelances commettent des erreurs qui coûtent cher.

## Erreur 1 : Ignorer la légalité

**Le problème :** Scraper des données sans respecter la GDPR ou les ToS des sites.

**La solution :** Consulte le [guide GDPR](https://gdpr-info.eu/) et respecte les robots.txt. Lis cet article sur [la légalité du web scraping](https://blog.apify.com/is-web-scraping-legal/).

## Erreur 2 : Ne pas valider les données

**Le problème :** Des emails invalides, des doublons, des données obsolètes.

**La solution :** Utilise des outils comme [Hunter.io](https://www.hunter.io/) pour valider les emails. Déduplique toujours.

## Erreur 3 : Scraper trop vite

**Le problème :** Se faire bloquer par le site.

**La solution :** Ajoute des délais entre les requêtes. Utilise des proxies.

## Erreur 4 : Ignorer la qualité des données

**Le problème :** Des données incomplètes ou incorrectes.

**La solution :** Lis les [meilleures pratiques de qualité de données](https://www.gartner.com/en/information-technology/insights/data-quality) de Gartner.

## Erreur 5 : Ne pas enrichir les données

**Le problème :** Une simple liste d'emails n'a pas de valeur.

**La solution :** Enrichis avec le poste, l'entreprise, le téléphone, LinkedIn, etc.

## Conclusion

La qualité des données = la qualité des leads.

**Cet article fait partie du [Guide Complet de l'Automatisation B2B](/guide-automatisation-b2b), qui couvre tous les aspects de l'automatisation.**`,
  },
  {
    id: "lead-enrichment",
    title: "Enrichissement de leads : La vraie stratégie",
    excerpt:
      "Transformez une simple liste d'entreprises en base de prospection complète. Emails vérifiés, numéros directs, postes décisionnaires.",
    date: "2026-06-30",
    readTime: 11, // écart source — index : « Enrichir une base de leads : la vraie stratégie », catégorie « Données », 13 min
    category: "Leads",
    author: "Romain",
    sources: [
      { title: "Hunter.io Lead Enrichment", url: "https://www.hunter.io/" },
      { title: "RocketReach Data", url: "https://www.rocketreach.co/" },
      { title: "Clearbit Data API", url: "https://clearbit.com/" },
      { title: "LinkedIn Data API", url: "https://www.linkedin.com/developers" },
    ],
    relatedPillar: PILLAR,
    content: `# Enrichissement de leads : La vraie stratégie

Une simple liste d'emails n'a aucune valeur. Un lead enrichi avec le poste, l'entreprise, le téléphone et LinkedIn ? Ça vaut de l'or.

## Qu'est-ce que l'enrichissement de leads ?

C'est transformer une simple liste d'emails en **base de prospection complète**.

**Exemple :**
- Avant : "john@company.com"
- Après : "John Smith, CEO, TechCorp, +33 6 12 34 56 78, LinkedIn: linkedin.com/in/johnsmith"

## Les 5 données essentielles à enrichir

1. **Email vérifié** → [Hunter.io](https://www.hunter.io/)
2. **Poste et entreprise** → [RocketReach](https://www.rocketreach.co/)
3. **Téléphone direct** → [Clearbit](https://clearbit.com/)
4. **Profil LinkedIn** → [LinkedIn API](https://www.linkedin.com/developers)
5. **Secteur et taille** → Données publiques

## Outils recommandés

- **Hunter.io** : Meilleur rapport qualité-prix
- **RocketReach** : Plus complet mais plus cher
- **Clearbit** : API puissante pour l'enrichissement en masse
- **LinkedIn API** : Données officielles mais limitées

## Processus d'enrichissement en 3 étapes

1. **Extraction** : Scrape les emails
2. **Validation** : Vérifie les emails avec Hunter
3. **Enrichissement** : Ajoute les données avec RocketReach/Clearbit

## Résultats

- ✅ Taux de délivrabilité email : +40%
- ✅ Taux de réponse : +60%
- ✅ Qualification des leads : +80%

## Conclusion

L'enrichissement de leads est l'étape la plus importante de la prospection.

**Cet article fait partie du [Guide Complet de l'Automatisation B2B](/guide-automatisation-b2b), qui couvre tous les aspects de l'automatisation.**`,
  },
];

// Tri antéchronologique : l'ordre d'affichage ne dépend pas de l'ordre du
// tableau ci-dessus, pour qu'ajouter un article en fin de fichier suffise.
export const ARTICLES_BY_DATE = [...ARTICLES].sort((a, b) => b.date.localeCompare(a.date));

export function getArticle(id) {
  return ARTICLES.find((a) => a.id === id) ?? null;
}

// Article précédent / suivant dans l'ordre de lecture (antéchronologique).
export function getSiblings(id) {
  const i = ARTICLES_BY_DATE.findIndex((a) => a.id === id);
  if (i === -1) return { prev: null, next: null };
  return {
    prev: ARTICLES_BY_DATE[i - 1] ?? null,
    next: ARTICLES_BY_DATE[i + 1] ?? null,
  };
}

export function getArticlesByCategories(categories) {
  return ARTICLES_BY_DATE.filter((a) => categories.includes(a.category));
}

export function getCluster(slug) {
  return CLUSTERS.find((c) => c.slug === slug) ?? null;
}

// Format FR court : « 3 juil. 2026 ». Intl plutôt qu'une table de mois maison,
// pour que la locale reste cohérente si le site devient multilingue.
export function formatDate(iso) {
  return new Date(`${iso}T12:00:00`).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}
