// Avis clients — repris VERBATIM du site en production
// (client/src/components/SocialProofSection.tsx), récupérés dans le bundle JS.
//
// Rien n'est inventé ici, et rien ne doit l'être : un témoignage nominatif
// fabriqué est une pratique trompeuse, sanctionnée comme telle. Si l'un de ces
// avis n'est pas authentique, il faut le retirer, pas le réécrire.
//
// Chaque avis porte un chiffre. C'est ce qui les distingue d'un « super
// travail, je recommande » : le lecteur repart avec un ordre de grandeur.

export const AVIS = [
  {
    citation:
      'Romain a automatisé notre pipeline complet. 15h de travail économisées par semaine.',
    nom: 'Thomas D.',
    role: 'CEO, agence SaaS',
    metrique: '15 h',
    unite: 'économisées par semaine',
  },
  {
    citation: 'Il a construit un scraper qui extrait 100K données/jour. Parfait.',
    nom: 'Alexandre R.',
    role: 'Fondateur, startup fintech',
    metrique: '100 K',
    unite: 'données par jour',
  },
  {
    citation: 'Tous nos outils sont maintenant sync en temps réel. Un game-changer.',
    nom: 'Julien P.',
    role: 'Co-fondateur, agence digitale',
    metrique: '100 %',
    unite: 'synchronisation automatique',
  },
];
