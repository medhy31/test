// Gwen — utilitaires de contenu markdown, séparés du composant de rendu.
//
// Ils vivent dans leur propre fichier pour deux raisons : le Fast Refresh de
// React ne fonctionne que sur un module qui n'exporte QUE des composants (un
// fichier mixte force un rechargement complet à chaque frappe), et ces
// fonctions servent aussi hors rendu — le sommaire de BlogPost et de Pillar
// les appelle sans monter ArticleBody.

// Slug ASCII stable : sert d'ancre de titre ET de cible au sommaire, donc les
// deux DOIVENT passer par cette fonction (jamais par un index de boucle, qui
// casserait les liens dès qu'un titre est inséré au milieu de l'article).
export function slugify(text) {
  return text
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '') // diacritiques isolés par NFD
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

// Version texte nu, pour le sommaire et les attributs (title, aria-label).
export function stripInline(text) {
  return text.replace(/\*\*(.+?)\*\*/g, '$1').replace(/\[(.+?)\]\((.+?)\)/g, '$1');
}

// Sommaire : uniquement les ## (les ### sont trop fins pour une colonne
// latérale, et le # de tête duplique le titre de la page).
export function extractHeadings(markdown) {
  return markdown
    .split('\n')
    .filter((line) => /^##\s+/.test(line))
    .map((line) => {
      const text = line.replace(/^##\s+/, '').trim();
      return { id: slugify(text), text: stripInline(text) };
    });
}
