// Point de branchement unique du formulaire.
//
// Isolé dans un seul fichier pour qu'un changement de destination — n8n, un
// service de formulaire, une API maison — ne touche jamais au composant.
//
// En production la demande part vers /api/devis, une fonction servie par
// l'hébergeur à la MÊME adresse que le site (voir functions/api/devis.js).
// C'est ce qui permet de se passer à la fois d'un nom de domaine et d'un
// serveur : l'hébergeur fournit le HTTPS, et le secret du bot Telegram reste
// côté serveur au lieu d'être compilé dans le JavaScript public.
//
// VITE_WEBHOOK reste prioritaire pour viser un n8n directement — c'est ce qu'on
// fait en développement, où l'instance tourne sur la machine. Attention : cette
// URL-là doit être en HTTPS dès que le site l'est, sinon le navigateur bloque
// la requête avant même qu'elle parte et l'erreur n'apparaît qu'en console.
export const WEBHOOK = import.meta.env.VITE_WEBHOOK || '/api/devis';

// Adresse de repli, affichée si l'envoi échoue. Elle n'est jamais montrée quand
// tout fonctionne : c'est une issue de secours, pas une alternative offerte.
export const EMAIL_SECOURS = 'mentionromain@gmail.com';

/**
 * Envoie la demande. Renvoie true si elle est bien partie.
 *
 * Toute erreur est renvoyée comme un échec plutôt que propagée : l'appelant
 * doit pouvoir afficher le repli, pas planter. Un formulaire qui échoue en
 * silence, c'est un lead perdu sans qu'on le sache — exactement le mode de
 * panne qu'on cherche à éliminer.
 */
export async function envoyerDemande(donnees) {
  try {
    // Délai de garde : sans lui, un serveur qui ne répond pas laisse la
    // personne devant un bouton figé, sans savoir si c'est parti.
    const stop = AbortSignal.timeout(10000);
    const reponse = await fetch(WEBHOOK, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(donnees),
      signal: stop,
    });
    return reponse.ok;
  } catch {
    return false;
  }
}
