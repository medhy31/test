import { useEffect, useMemo, useRef, useState } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { Edges, Text } from '@react-three/drei';
import * as THREE from 'three';
import { RoomEnvironment } from 'three-stdlib';
import { useNavigate } from 'react-router-dom';
import { scrollState } from './scrollStore';
import { CLUSTERS } from '../content/articles';

/**
 * LA VILLE — scène du guide.
 *
 * Réemploi de la maquette isométrique héritée du projet (FinalDemo), sortie de
 * son rôle de démonstration pour devenir un MENU : une tour par branche du
 * guide, cliquable, qui mène à la page correspondante.
 *
 * Elle ne remplace pas la navigation en HTML posée sous le canvas — une scène
 * 3D n'est pas atteignable au clavier et n'est pas lue par un lecteur d'écran.
 * Les deux montrent les mêmes trois destinations ; celle-ci ajoute le plaisir,
 * l'autre garantit l'accès.
 */

const TOURS = [
  { x: -3.8, z: 1.4, h: 4.4 },
  { x: 0.4, z: -1.6, h: 6.2 },
  { x: 4.4, z: 1.2, h: 3.6 },
];

// Bâtiments muets, autour des trois tours : sans eux, trois volumes seuls dans
// le vide ne font pas une ville, juste trois boîtes.
// Le décor est nettement plus bas que les trois tours : au premier essai il
// avait la même hauteur qu'elles et venait les masquer depuis la caméra, la
// ville n'était plus qu'un tas de boîtes indistinctes.
const DECOR = Array.from({ length: 18 }, (_, i) => {
  const a = (i / 18) * Math.PI * 2;
  const r = 7.5 + ((i * 37) % 5);
  return {
    x: Math.cos(a) * r,
    z: Math.sin(a) * r * 0.65,
    h: 0.5 + ((i * 53) % 8) / 8,
    w: 0.9 + ((i * 17) % 5) / 6,
  };
});

function useStudio() {
  const { gl, scene } = useThree();
  useEffect(() => {
    const pmrem = new THREE.PMREMGenerator(gl);
    const room = new RoomEnvironment();
    const target = pmrem.fromScene(room, 0.04);
    scene.environment = target.texture;
    scene.background = new THREE.Color('#f2f0ec');
    return () => {
      target.dispose();
      pmrem.dispose();
      room.dispose?.();
      scene.environment = null;
    };
  }, [gl, scene]);
}

/* ------------------------------------------------------------------ caméra */
// Vue isométrique quasi fixe : la ville est un objet qu'on REGARDE, pas un
// espace qu'on traverse. Le défilement ne fait que la faire pivoter lentement,
// juste assez pour qu'elle ne paraisse pas être une image.
function Rig() {
  // La caméra vise un point décalé à GAUCHE du centre de la ville : la ville se
  // retrouve donc dans la moitié droite du cadre, là où le texte de la page ne
  // va pas. Viser le centre la plaçait pile derrière le titre.
  const cible = useRef(new THREE.Vector3(-7, 1.4, 0));

  useFrame((state) => {
    const t = scrollState.progress;
    const angle = 0.7 + t * 0.45;
    // Reculée : à 15 unités les bâtiments du premier plan débordaient du cadre
    // et écrasaient les tours.
    const rayon = 27 - t * 3;
    state.camera.position.set(Math.sin(angle) * rayon, 15 - t * 3, Math.cos(angle) * rayon);
    state.camera.lookAt(cible.current);
  });

  return null;
}

/* -------------------------------------------------------------------- tour */
function Tour({ tour, cluster, index, actif, onSurvol, onSortie, onClic }) {
  const groupe = useRef();
  const [survole, setSurvole] = useState(false);

  useFrame(() => {
    if (!groupe.current) return;
    // La tour se soulève quand elle est désignée. lerp plutôt qu'une transition
    // CSS : on est dans la boucle de rendu, et l'amortissement donne le poids
    // qu'on attend d'un volume de cette taille.
    const cible = actif ? 0.45 : 0;
    groupe.current.position.y += (cible - groupe.current.position.y) * 0.12;
  });

  const arete = actif ? '#ff4d1c' : '#8f8b84';

  return (
    <group
      ref={groupe}
      position={[tour.x, 0, tour.z]}
      onPointerOver={(e) => {
        e.stopPropagation();
        setSurvole(true);
        onSurvol();
        document.body.style.cursor = 'pointer';
      }}
      onPointerOut={() => {
        setSurvole(false);
        onSortie();
        document.body.style.cursor = '';
      }}
      onClick={(e) => {
        e.stopPropagation();
        onClic();
      }}
    >
      {/* Corps chromé : sur fond ivoire, c'est l'arête qui dessine le volume,
          pas la face. Le même parti pris que les portiques de la traversée. */}
      <mesh position={[0, tour.h / 2, 0]}>
        <boxGeometry args={[2, tour.h, 2]} />
        <meshStandardMaterial color="#cbc7c0" metalness={0.85} roughness={0.2} />
        <Edges color={arete} threshold={15} />
      </mesh>

      <mesh position={[0, tour.h + 0.18, 0]}>
        <boxGeometry args={[1.4, 0.36, 1.4]} />
        <meshStandardMaterial color="#d8d4cd" metalness={0.6} roughness={0.3} />
        <Edges color={arete} />
      </mesh>

      <Text
        position={[0, tour.h + 1.1, 0]}
        fontSize={0.42}
        color={actif ? '#ff4d1c' : '#55524c'}
        anchorX="center"
        anchorY="middle"
        outlineWidth={0.02}
        outlineColor="#f2f0ec"
      >
        {String(index + 1).padStart(2, '0')}
      </Text>

      {survole && (
        <Text
          position={[0, tour.h + 0.66, 0]}
          fontSize={0.3}
          color="#0a0a0a"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.02}
          outlineColor="#f2f0ec"
        >
          {cluster.label}
        </Text>
      )}
    </group>
  );
}

/* ------------------------------------------------------------------- scène */
export default function Ville({ actif, setActif }) {
  useStudio();
  const navigate = useNavigate();

  const decorGeo = useMemo(() => new THREE.BoxGeometry(1, 1, 1), []);
  const decorMat = useMemo(
    () => new THREE.MeshStandardMaterial({ color: '#dedad4', metalness: 0.5, roughness: 0.45 }),
    [],
  );

  return (
    <>
      <fog attach="fog" args={['#f2f0ec', 26, 75]} />
      <Rig />

      <ambientLight intensity={0.65} />
      <directionalLight position={[8, 14, 6]} intensity={1} />

      {/* Le sol en grille : écho direct de la grille pointillée du site et de
          l'esthétique « plan technique ». */}
      <gridHelper args={[70, 46, '#c9c5be', '#e2ded8']} position={[0, -0.01, 0]} />

      {TOURS.map((tour, i) => (
        <Tour
          key={CLUSTERS[i].slug}
          tour={tour}
          cluster={CLUSTERS[i]}
          index={i}
          actif={actif === i}
          onSurvol={() => setActif(i)}
          onSortie={() => setActif(null)}
          onClic={() => navigate(CLUSTERS[i].slug)}
        />
      ))}

      {DECOR.map((b, i) => (
        <mesh
          key={i}
          geometry={decorGeo}
          material={decorMat}
          position={[b.x, b.h / 2, b.z]}
          scale={[b.w, b.h, b.w]}
        />
      ))}
    </>
  );
}
