import { createContext, useContext, useEffect } from 'react';

/**
 * Réglages de la scène, page par page.
 *
 * Le canvas est monté UNE FOIS dans App.jsx et ne se démonte jamais. C'est ce
 * qui permet des transitions de page : si chaque page montait son propre
 * <Canvas>, chaque navigation détruirait puis recréerait un contexte WebGL —
 * plusieurs centaines de millisecondes d'écran vide au milieu du fondu, et
 * l'environnement à recalculer à chaque fois.
 *
 * Deux canaux, selon la nature du réglage :
 *
 *  - `sceneState` est un objet mutable, lu directement dans les boucles
 *    useFrame. Il porte ce qui change à chaque image (la course de la caméra,
 *    l'avancement du basculement sombre). Le passer par un état React
 *    re-rendrait tout l'arbre soixante fois par seconde.
 *
 *  - le contexte React porte ce qui change à chaque NAVIGATION, c'est-à-dire
 *    rarement : faut-il un post-traitement, quelle scène afficher. Là, un
 *    re-render est justifié — il faut bien reconstruire l'arbre 3D.
 */

export const sceneState = {
  /** Distance parcourue par la caméra sur toute la hauteur de la page. */
  depth: 74,
  /** 0 = plein jour ivoire, 1 = nuit. Interpolé pendant le défilement. */
  night: 0,
};

const SceneContext = createContext(() => {});

export const SceneProvider = SceneContext.Provider;

/**
 * À appeler en tête de chaque page.
 * @param {object} reglage
 * @param {number} reglage.depth  course de la caméra
 * @param {boolean} [reglage.bloom]  post-traitement (coûteux, réservé aux pages qui basculent en nuit)
 * @param {string} [reglage.scene]  variante de scène ('atelier' par défaut, 'ville' pour le guide)
 */
export function useScene({ depth, bloom = false, scene = 'atelier' }) {
  const setScene = useContext(SceneContext);

  useEffect(() => {
    sceneState.depth = depth;
    // Une page qui ne bascule pas en nuit doit repartir de plein jour : sans
    // cette remise à zéro, on quitte l'accueil au milieu du passage sombre et
    // on arrive sur un article dans le noir.
    if (!bloom) sceneState.night = 0;
    setScene({ bloom, scene });
  }, [depth, bloom, scene, setScene]);
}
