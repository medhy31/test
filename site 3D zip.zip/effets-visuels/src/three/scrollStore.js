// Position de défilement partagée entre le DOM et la scène 3D.
//
// Même principe que pointerStore.js : un objet mutable, lu dans les boucles
// useFrame, jamais dans du JSX. Le scroll change à chaque image ; le passer par
// un état React re-rendrait tout l'arbre 60 fois par seconde pour déplacer une
// caméra.
//
// Pourquoi le scroll NATIF du document plutôt que le <ScrollControls> de drei ?
// drei crée son propre conteneur de défilement à l'intérieur du canvas et y
// injecte le HTML. C'est fait pour une expérience entièrement pilotée par la
// 3D, pas pour un site qui a du contenu : on y perd le défilement natif (donc
// l'inertie du trackpad, la molette, les touches Début/Fin, la barre de
// défilement, la restauration de position au retour arrière), le contenu
// dépend du canvas pour s'afficher, et le moindre incident WebGL laisse une
// page figée sur laquelle on ne peut plus rien faire.
//
// Ici c'est l'inverse : le document scrolle normalement, la scène se contente
// de LIRE cette position. Si le WebGL disparaît, il reste un site qui marche.

export const scrollState = {
  /** Progression du document, de 0 (haut) à 1 (bas). */
  progress: 0,
  /** Position en pixels, utile pour les effets calés sur une distance réelle. */
  y: 0,
};

let bound = false;

/**
 * Branche la mise à jour du store sur le défilement de la fenêtre.
 * Renvoie la fonction de nettoyage à appeler au démontage.
 */
export function bindScroll() {
  if (bound) return () => {};
  bound = true;

  const update = () => {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    scrollState.y = window.scrollY;
    // Garde-fou : sur une page plus courte que la fenêtre, max vaut 0 et la
    // division donnerait NaN, qui se propagerait dans la position de la caméra
    // et ferait disparaître la scène.
    scrollState.progress = max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 0;
  };

  update();
  // passive: true — on ne fait que lire, jamais preventDefault. Sans ce
  // drapeau, le navigateur doit attendre la fin du handler avant de défiler,
  // ce qui produit un scroll saccadé.
  window.addEventListener('scroll', update, { passive: true });
  window.addEventListener('resize', update);

  return () => {
    window.removeEventListener('scroll', update);
    window.removeEventListener('resize', update);
    bound = false;
  };
}
