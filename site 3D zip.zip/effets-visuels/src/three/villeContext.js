import { createContext, useContext } from 'react';

/**
 * Tour survolée dans la ville du guide.
 *
 * La scène 3D et la fiche descriptive vivent de part et d'autre du canvas :
 * l'une dessine les tours, l'autre affiche du HTML sélectionnable et lisible
 * par un lecteur d'écran. Ce contexte est le seul point de rencontre entre les
 * deux — sans lui, il faudrait remonter l'état par des props à travers toute
 * l'application.
 */
export const VilleContext = createContext({ villeActive: null, setVilleActive: () => {} });

export const useVille = () => useContext(VilleContext);
