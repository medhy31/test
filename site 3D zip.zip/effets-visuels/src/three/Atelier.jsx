import { useEffect, useMemo, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { MeshTransmissionMaterial } from '@react-three/drei';
import * as THREE from 'three';
import { RoomEnvironment } from 'three-stdlib';
import { scrollState } from './scrollStore';
import { sceneState } from './sceneStore';

/**
 * LA TRAVERSÉE
 *
 * Le site n'a pas de fond 3D : il EST la scène. Le scroll ne fait pas défiler
 * une page devant un décor, il fait AVANCER la caméra dans un espace, et le
 * contenu est posé aux endroits qu'on franchit.
 *
 * Le vocabulaire est industriel : des PORTIQUES qu'on traverse (sans eux on
 * flotterait dans du vide — c'est le défilement des cadres qui crée la vitesse,
 * pas le mouvement de la caméra), des MODULES en bord de champ dont une partie
 * est en verre réfractant, et une seule masse vermillon.
 *
 * ---------------------------------------------------------------------------
 * BUDGET DE RENDU — la scène tourne en plein écran en permanence :
 *   - aucune ombre portée (une shadow map re-rend toute la scène par image) ;
 *   - aucun HDRI téléchargé, l'environnement est calculé en local une fois ;
 *   - une seule boucle d'animation pour tous les objets ;
 *   - géométries et matériaux partagés entre instances ;
 *   - le verre est limité à quatre blocs : MeshTransmissionMaterial re-rend la
 *     scène dans une texture pour chaque objet, c'est le matériau le plus cher
 *     du site. Quatre passent, quinze effondreraient le framerate.
 * ---------------------------------------------------------------------------
 */

export const DEPTH = 74;

// Position, en fraction du défilement, de la station de respiration de la page
// d'accueil — le moment où le contenu se tait et où la scène prend toute la
// place. La masse vermillon est posée là, et la bascule nuit est calée dessus
// (voir Home.jsx).
//
// ATTENTION : cette valeur dépend du NOMBRE de sections de l'accueil. Ajouter
// une station décale la respiration et désynchronise les deux effets — la masse
// se met alors à écraser une section de texte. Pour la remesurer :
//   [...document.querySelectorAll('.station')].map(el => (
//     el.getBoundingClientRect().top + scrollY + el.offsetHeight / 2) /
//     (document.documentElement.scrollHeight - innerHeight))
export const RESPIRATION = 0.79;
const GATES = 12;
const GATE_GAP = 9;
const MODULES = 19;
// Un module sur cinq est en verre : assez pour qu'on en croise régulièrement,
// assez peu pour que le coût reste tenable.
const VERRE = new Set([2, 6, 11, 15]);

const JOUR = new THREE.Color('#f2f0ec');
const NUIT = new THREE.Color('#0d0c0b');

/* ------------------------------------------------------------------ caméra */
function Rig() {
  const look = useRef(new THREE.Vector3());
  // Position lissée : le défilement natif arrive par paliers (une molette = un
  // saut de plusieurs dizaines de pixels). Appliqué tel quel, le déplacement
  // serait haché.
  const eased = useRef(0);

  useFrame((state, delta) => {
    // Lissage indépendant du framerate : à 30 comme à 120 images par seconde,
    // la caméra met le même temps à rattraper la cible.
    const k = 1 - Math.pow(0.0015, delta);
    eased.current += (scrollState.progress - eased.current) * k;
    const t = eased.current;

    state.camera.position.z = 6 - t * sceneState.depth;

    // Dérive latérale et verticale : sans elle, la caméra suit un rail droit et
    // le déplacement devient illisible — on ne perçoit plus qu'un zoom.
    state.camera.position.x = Math.sin(t * Math.PI * 2.2) * 1.6;
    state.camera.position.y = 0.5 + Math.sin(t * Math.PI * 3.1) * 0.45;

    // Le regard vise loin devant : on conduit, on n'est pas tracté.
    look.current.set(Math.sin(t * Math.PI * 2.2) * 0.8, 0.2, state.camera.position.z - 14);
    state.camera.lookAt(look.current);
  });

  return null;
}

/* --------------------------------------------------------------- positions */
// Générateur déterministe : un Math.random() nu redistribuerait toute la scène
// à chaque rechargement à chaud, et rendrait impossible de caler le texte sur
// ce qu'on voit.
function seeded(i) {
  const x = Math.sin(i * 127.1) * 43758.5453;
  return x - Math.floor(x);
}

/* ------------------------------------------------------------ environnement */
/**
 * Un métal ne fabrique pas son image, il RÉFLÉCHIT. Sans carte d'environnement,
 * metalness:1 ne renvoie rien et l'objet rend noir.
 *
 * RoomEnvironment est une petite pièce éclairée, construite en géométrie pure
 * par three : aucun fichier à télécharger, et elle couvre toute la sphère. On
 * la passe une fois dans le PMREMGenerator puis on libère les ressources.
 */
function useStudio() {
  const { gl, scene } = useThree();

  useEffect(() => {
    const pmrem = new THREE.PMREMGenerator(gl);
    const room = new RoomEnvironment();
    const target = pmrem.fromScene(room, 0.04);
    scene.environment = target.texture;

    return () => {
      target.dispose();
      pmrem.dispose();
      room.dispose?.();
      scene.environment = null;
    };
  }, [gl, scene]);
}

/* ------------------------------------------------------------------- scène */
export default function Atelier() {
  useStudio();
  const { scene } = useThree();
  const gatesRef = useRef();
  const modulesRef = useRef();
  const flareRef = useRef();
  const lumiereRef = useRef();

  // Le métal poli à metalness:1 ne renvoie QUE ce qu'il réfléchit : sur une
  // surface fine et courbe comme un anneau, l'essentiel de ce qu'il attrape est
  // le bas de l'environnement, sombre — d'où des cercles presque noirs. On
  // descend donc le métal et on remonte la couleur propre.
  const ring = useMemo(
    () => new THREE.MeshStandardMaterial({ color: '#d8d4cd', metalness: 0.55, roughness: 0.28 }),
    [],
  );
  // Les blocs gardent plus de métal : ce sont des volumes pleins, ils captent
  // assez d'environnement pour rester clairs.
  const chrome = useMemo(
    () => new THREE.MeshStandardMaterial({ color: '#cbc7c0', metalness: 0.85, roughness: 0.22 }),
    [],
  );
  const flareMat = useMemo(
    () => new THREE.MeshStandardMaterial({ color: '#ff4d1c', metalness: 0, roughness: 0.55 }),
    [],
  );
  const gateGeo = useMemo(() => new THREE.TorusGeometry(5.2, 0.07, 10, 64), []);
  const boxGeo = useMemo(() => new THREE.BoxGeometry(1, 1, 1), []);

  const modules = useMemo(
    () =>
      Array.from({ length: MODULES }, (_, i) => ({
        // Écart latéral minimum de 8.5 unités : en deçà, un bloc passe devant la
        // colonne de texte au moment où la caméra le croise.
        position: [
          (i % 2 ? 1 : -1) * (8.5 + seeded(i) * 3.5),
          (seeded(i + 40) - 0.5) * 6,
          -8 - i * 5,
        ],
        scale: [0.5 + seeded(i + 80) * 1.4, 0.5 + seeded(i + 120) * 1, 0.5 + seeded(i + 160) * 1.4],
        phase: seeded(i + 200) * Math.PI * 2,
        speed: 0.35 + seeded(i + 240) * 0.4,
        verre: VERRE.has(i),
      })),
    [],
  );

  const fond = useMemo(() => new THREE.Color(JOUR), []);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const nuit = sceneState.night;

    // ---- bascule jour / nuit -----------------------------------------------
    // Le fond ET le brouillard partagent exactement la même couleur : c'est
    // cette égalité qui fait disparaître l'horizon. Ils sont donc interpolés
    // ensemble, sinon un mur apparaîtrait au fond pendant la transition.
    fond.copy(JOUR).lerp(NUIT, nuit);
    scene.background = fond;
    if (scene.fog) scene.fog.color.copy(fond);

    // En nuit, le métal n'a plus grand-chose de clair à réfléchir : on baisse
    // l'apport de l'environnement et on allume les objets de l'intérieur. C'est
    // ce qui donne au Bloom quelque chose à faire rayonner — sans émissif, un
    // post-traitement de lueur n'a aucune prise.
    ring.envMapIntensity = 1 - nuit * 0.7;
    chrome.envMapIntensity = 1 - nuit * 0.7;
    ring.emissive.setRGB(nuit * 0.05, nuit * 0.14, nuit * 0.18);
    flareMat.emissive.setRGB(nuit * 1.3, nuit * 0.32, nuit * 0.08);

    if (lumiereRef.current) lumiereRef.current.intensity = 0.9 - nuit * 0.55;

    // ---- animation ----------------------------------------------------------
    if (gatesRef.current) {
      // Cadres jamais alignés : évite l'effet « couloir de jeu vidéo ».
      const children = gatesRef.current.children;
      for (let i = 0; i < children.length; i += 1) {
        children[i].rotation.z = i * 0.4 + t * 0.04 * (i % 2 ? 1 : -1);
      }
    }

    if (modulesRef.current) {
      const children = modulesRef.current.children;
      for (let i = 0; i < children.length; i += 1) {
        const m = modules[i];
        children[i].position.y = m.position[1] + Math.sin(t * m.speed + m.phase) * 0.5;
        children[i].rotation.x = t * m.speed * 0.18 + m.phase;
        children[i].rotation.y = t * m.speed * 0.24;
      }
    }

    if (flareRef.current) {
      flareRef.current.rotation.x = t * 0.12;
      flareRef.current.rotation.y = t * 0.18;
    }
  });

  return (
    <>
      <fog attach="fog" args={['#f2f0ec', 9, 34]} />

      <Rig />

      <ambientLight intensity={0.6} />
      <directionalLight ref={lumiereRef} position={[6, 10, 4]} intensity={0.9} />

      <group ref={gatesRef}>
        {Array.from({ length: GATES }, (_, i) => (
          <mesh key={i} geometry={gateGeo} material={ring} position={[0, 0, -i * GATE_GAP]} />
        ))}
      </group>

      <group ref={modulesRef}>
        {modules.map((m, i) =>
          m.verre ? (
            // Verre réfractant. Sur fond ivoire il prend tout son sens : il
            // DÉFORME ce qu'il y a derrière au lieu de se contenter de briller,
            // ce qu'un objet transparent sur fond noir ne peut pas montrer.
            <mesh key={i} geometry={boxGeo} position={m.position} scale={m.scale}>
              <MeshTransmissionMaterial
                samples={4}
                resolution={256}
                thickness={0.9}
                ior={1.45}
                chromaticAberration={0.06}
                anisotropy={0.1}
                roughness={0.05}
                distortion={0.2}
                distortionScale={0.3}
                temporalDistortion={0.1}
              />
            </mesh>
          ) : (
            <mesh
              key={i}
              geometry={boxGeo}
              material={chrome}
              position={m.position}
              scale={m.scale}
            />
          ),
        )}
      </group>

      {/* La seule couleur de la scène, à mi-parcours et au centre du champ : on
          la voit venir de loin dans la brume, on la traverse, elle disparaît.
          Mate au milieu d'objets qui reflètent tous — et c'est elle qui s'embrase
          quand la scène bascule en nuit. */}
      <mesh ref={flareRef} material={flareMat} position={[0, 0.2, 6 - RESPIRATION * DEPTH]}>
        <icosahedronGeometry args={[1.5, 0]} />
      </mesh>
    </>
  );
}
