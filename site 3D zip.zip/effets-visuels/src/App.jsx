import { lazy, Suspense, useCallback, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import Stage from './components/Stage';
import { SceneProvider } from './three/sceneStore';
import { VilleContext } from './three/villeContext';
import Home from './pages/Home';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Blog from './pages/Blog';
import BlogPost from './pages/BlogPost';
import Cluster from './pages/Cluster';
import Start from './pages/Start';
import Etude from './pages/Etude';
import Apropos from './pages/Apropos';
import NotFound from './pages/NotFound';

// Le guide passe en import différé : c'est la page la plus lourde du site (le
// texte intégral plus sa propre scène), et la moins visitée en entrée directe.
const Pillar = lazy(() => import('./pages/Pillar'));

function RouteFallback() {
  return (
    <div className="route-fallback" role="status" aria-live="polite">
      <span className="route-fallback__bar" />
      <span className="route-fallback__label">Chargement…</span>
    </div>
  );
}

/**
 * La transition de page.
 *
 * Volontairement sobre : un fondu et quelques pixels de glissement. Le site a
 * déjà un mouvement permanent — la caméra qui avance dans la scène — et une
 * transition spectaculaire par-dessus donnerait deux mouvements qui se
 * disputent l'attention.
 *
 * `mode="wait"` : la page sortante finit son fondu avant que l'entrante ne
 * commence. Sans ça, les deux se superposent une fraction de seconde et on voit
 * deux titres l'un sur l'autre.
 *
 * La scène 3D ne fait pas partie de la transition : elle vit hors de
 * l'AnimatePresence et continue de tourner pendant le changement. C'est ce qui
 * donne la continuité — on change de page sans quitter l'espace.
 */
const pageVariants = {
  entree: { opacity: 0, y: 12 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.45, ease: [0.16, 1, 0.3, 1] } },
  sortie: { opacity: 0, y: -8, transition: { duration: 0.28, ease: [0.4, 0, 1, 1] } },
};

function AnimatedRoutes() {
  const location = useLocation();
  const reduceMotion = useReducedMotion();

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={location.pathname}
        initial={reduceMotion ? false : 'entree'}
        animate="visible"
        exit={reduceMotion ? undefined : 'sortie'}
        variants={pageVariants}
      >
        <Suspense fallback={<RouteFallback />}>
          <Routes location={location}>
            <Route path="/" element={<Home />} />
            <Route path="/services" element={<Services />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/demarrer" element={<Start />} />
            {/* La seule page du site qui prouve au lieu d'affirmer. */}
            <Route path="/realisations" element={<Etude />} />
            <Route path="/a-propos" element={<Apropos />} />

            {/* Blog et arborescence SEO. Le guide et ses trois branches forment
                un maillage : chaque branche remonte vers le guide, le guide
                redescend vers les articles. Ne pas rompre ces chemins. */}
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:id" element={<BlogPost />} />
            <Route path="/guide-automatisation-b2b" element={<Pillar />} />
            <Route path="/scraping-linkedin" element={<Cluster slug="/scraping-linkedin" />} />
            <Route
              path="/automation-workflows"
              element={<Cluster slug="/automation-workflows" />}
            />
            <Route path="/generation-leads" element={<Cluster slug="/generation-leads" />} />

            {/* Attrape-tout : sans lui, une adresse inconnue rend une page
                entièrement vide, sans message ni moyen de repartir. */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
      </motion.div>
    </AnimatePresence>
  );
}

export default function App() {
  // Réglages de scène demandés par la page courante. Ils ne changent qu'à la
  // navigation, d'où un état React : reconstruire l'arbre 3D quelques fois par
  // session est sans conséquence. Ce qui change à chaque image passe par
  // sceneState (voir three/sceneStore.js).
  const [scene, setScene] = useState({ bloom: false, scene: 'atelier' });
  // Tour survolée dans la ville du guide. L'état vit ici et non dans la scène :
  // la fiche descriptive qui l'accompagne est du HTML, posé hors du canvas.
  const [villeActive, setVilleActive] = useState(null);

  // useCallback : sans identité stable, le setter changerait à chaque rendu de
  // App et le useEffect des pages se redéclencherait en boucle. La comparaison
  // évite en plus un rendu quand deux pages demandent le même réglage.
  const majScene = useCallback((valeur) => {
    setScene((precedent) =>
      precedent.bloom === valeur.bloom && precedent.scene === valeur.scene ? precedent : valeur,
    );
  }, []);

  return (
    <Router>
      <SceneProvider value={majScene}>
        <VilleContext.Provider value={{ villeActive, setVilleActive }}>
        <Stage
          bloom={scene.bloom}
          scene={scene.scene}
          villeActive={villeActive}
          setVilleActive={setVilleActive}
        />
        <div className="grain" aria-hidden="true" />
        <AnimatedRoutes />
        </VilleContext.Provider>
      </SceneProvider>
    </Router>
  );
}
