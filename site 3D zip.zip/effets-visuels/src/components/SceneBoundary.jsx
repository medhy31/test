import { Component } from 'react';

/**
 * Gwen — filet de sécurité autour des scènes WebGL.
 *
 * Pourquoi c'est nécessaire : une erreur levée pendant le rendu d'un <Canvas>
 * (WebGL désactivé dans le navigateur, pilote graphique refusé, contexte perdu
 * après une mise en veille, HDRI qui ne charge pas) remonte l'arbre React et
 * démonte TOUTE l'application — écran noir, y compris le texte qui n'a rien à
 * voir avec la 3D. Sur un site dont le fond est en WebGL sur chaque page
 * vitrine, c'est un risque qu'on ne prend pas.
 *
 * Ici, l'erreur est contenue : la scène est remplacée par un fond CSS de la
 * même famille visuelle (dégradé radial de marque, déjà défini dans les tokens)
 * et le reste de la page continue de vivre normalement. Le site perd son décor,
 * jamais son contenu.
 *
 * C'est une classe et non un composant à hooks parce que React ne propose
 * toujours pas d'équivalent de componentDidCatch côté hooks.
 */
export default class SceneBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { failed: false };
  }

  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentDidCatch(error) {
    // Pas de service de report externe sur ce projet : on trace en console pour
    // que l'erreur reste diagnosticable en développement.
    console.error('[SceneBoundary] scène 3D désactivée après une erreur :', error);
  }

  render() {
    if (this.state.failed) {
      return this.props.fallback ?? <div className="scene-fallback" aria-hidden="true" />;
    }
    return this.props.children;
  }
}
