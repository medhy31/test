import { Link } from 'react-router-dom';
import { formatDate } from '../content/articles';

/**
 * La liste d'articles — index de catalogue.
 *
 * Partagée par le journal, les pages cluster et le guide : une ligne pleine
 * largeur par article, numérotée, séparée par un filet. Un seul composant pour
 * les trois, sinon la même liste finit par diverger d'une page à l'autre.
 *
 * `start` décale la numérotation quand la liste ne commence pas à 1 (une page
 * cluster n'affiche qu'une partie du catalogue, mais numérote depuis 01 : c'est
 * son propre index, pas un extrait de celui du journal).
 */
export default function ArticleList({ articles, start = 1 }) {
  return (
    <ol className="index__list">
      {articles.map((article, i) => (
        <li key={article.id} className="index__row">
          <Link to={`/blog/${article.id}`} className="index__link">
            <span className="index__n t-tag">{String(i + start).padStart(2, '0')}</span>

            <span className="index__main">
              <span className="index__name">{article.title}</span>
              <span className="index__excerpt t-body">{article.excerpt}</span>
            </span>

            <span className="index__meta t-tag">
              <span className="index__cat">{article.category}</span>
              <time dateTime={article.date}>{formatDate(article.date)}</time>
              <span>{article.readTime} min</span>
            </span>

            {/* Flèche décorative : le libellé du lien est déjà le titre de
                l'article, elle ne doit pas être annoncée une seconde fois. */}
            <span className="index__go" aria-hidden="true">
              →
            </span>
          </Link>
        </li>
      ))}
    </ol>
  );
}
