import { Suspense, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { EffectComposer, Bloom } from '@react-three/postprocessing';
import Atelier from '../three/Atelier';
import Ville from '../three/Ville';
import SceneBoundary from './SceneBoundary';
import { sceneState } from '../three/sceneStore';

/**
 * Lueur pilotée par le basculement nuit.
 *
 * Le Bloom ne peut pas rester à intensité fixe : son seuil de luminance
 * s'applique à TOUTE l'image, et un fond ivoire est à ~0,94 de luminance. En
 * plein jour, la page entière dépassait donc le seuil et rayonnait — le rendu
 * devenait laiteux et les couleurs délavées, exactement l'inverse de la netteté
 * recherchée.
 *
 * L'intensité suit donc la nuit : nulle en plein jour, elle ne monte qu'une
 * fois le fond devenu sombre, là où seuls les objets allumés dépassent le
 * seuil. On écrit dans l'objet de l'effet plutôt que par une prop React, pour
 * ne pas re-render l'arbre 3D à chaque image.
 */
function LueurNuit() {
  const bloom = useRef();

  useFrame(() => {
    if (!bloom.current) return;
    const nuit = sceneState.night;
    bloom.current.intensity = nuit * 1.4;
    // Le seuil descend avec la nuit : très haut en jour (rien ne passe), plus
    // permissif ensuite pour laisser rayonner les arêtes et la masse vermillon.
    bloom.current.luminanceMaterial.threshold = 0.98 - nuit * 0.42;
  });

  return (
    <Bloom ref={bloom} intensity={0} luminanceThreshold={0.98} luminanceSmoothing={0.3} mipmapBlur />
  );
}

/**
 * La scène, montée UNE FOIS pour tout le site.
 *
 * Elle vit dans App.jsx et ne se démonte à aucune navigation. C'est ce qui rend
 * les transitions de page possibles : un <Canvas> par page détruirait puis
 * recréerait un contexte WebGL à chaque clic — plusieurs centaines de
 * millisecondes de vide au milieu du fondu, et l'environnement à recalculer.
 *
 * Les réglages qui changent d'une page à l'autre passent par sceneStore.js.
 */
export default function Stage({ bloom = false, scene = 'atelier', villeActive, setVilleActive }) {
  return (
    // SceneBoundary : une erreur levée pendant le rendu d'un <Canvas> (WebGL
    // désactivé, pilote refusé, contexte perdu au réveil de la machine) remonte
    // l'arbre React et démonte TOUTE l'application — y compris le texte, qui
    // n'a rien à voir avec la 3D. Ici l'incident est contenu : la scène est
    // remplacée par un fond CSS et la page continue de vivre.
    <SceneBoundary>
      <div className="stage" aria-hidden="true">
        <Canvas
          camera={{ position: [0, 0.5, 6], fov: 42 }}
          dpr={[1, 1.5]}
          // antialias désactivé : le grain posé par-dessus masque déjà
          // l'escalier des arêtes, et le multisampling sur un canvas plein
          // écran est l'un des postes les plus chers du rendu.
          gl={{ antialias: false, powerPreference: 'high-performance', toneMappingExposure: 1.15 }}
        >
          <Suspense fallback={null}>
            {scene === 'ville' ? (
              <Ville actif={villeActive} setActif={setVilleActive} />
            ) : (
              <Atelier />
            )}

            {/* Post-traitement réservé aux pages qui basculent en nuit. Il
                reste monté pendant toute la page — le monter et le démonter
                pendant le défilement coûterait bien plus cher que de le laisser
                tourner à intensité nulle. */}
            {bloom && (
              <EffectComposer>
                <LueurNuit />
              </EffectComposer>
            )}
          </Suspense>
        </Canvas>
      </div>
    </SceneBoundary>
  );
}
