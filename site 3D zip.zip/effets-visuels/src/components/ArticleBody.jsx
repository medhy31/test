import { Fragment, useMemo } from 'react';
import { slugify } from '../content/markdown';
import './ArticleBody.css';

/**
 * Gwen — rendu markdown maison, volontairement SANS dépendance.
 *
 * Pourquoi pas react-markdown / marked ? Le contenu du blog est écrit par une
 * seule personne, dans un sous-ensemble fermé et connu de markdown (titres,
 * gras, liens, listes, tableaux). Un parseur générique, c'est 40 à 100 ko de JS
 * en plus dans un bundle déjà à 1,5 Mo, pour couvrir des cas qu'on n'écrira
 * jamais — et surtout ça rend le HTML produit opaque, donc difficile à styler
 * finement (ici chaque bloc reçoit sa classe et son ancre).
 *
 * Sous-ensemble supporté, exhaustivement :
 *   #/##/###   titres (le # de tête est ignoré, voir plus bas)
 *   **gras**   emphase forte
 *   [t](url)   liens (externes -> nouvel onglet + rel de sécurité)
 *   - item     liste à puces
 *   1. item    liste numérotée
 *   | a | b |  tableau (avec sa ligne de séparation)
 *   ---        règle horizontale
 *   ✅ / ❌     en tête d'item : converti en pastille (voir renderListItem)
 *
 * Tout le reste est rendu tel quel en paragraphe : rien n'est jamais perdu.
 */

const isExternal = (href) => /^https?:\/\//.test(href);

// Découpe une ligne en gras / liens / texte. Un seul passage de regex avec
// alternance : découper en deux passes rendrait un lien dont le libellé est en
// gras (ou l'inverse) impossible à traiter proprement.
//
// La regex est déclarée DANS la fonction, et non au niveau du module : elle
// porte le drapeau /g, donc un `lastIndex` mutable, et la fonction s'appelle
// elle-même (voir plus bas). Une instance partagée verrait sa position écrasée
// par l'appel imbriqué, qui reprendrait la lecture au mauvais endroit.
function renderInline(text, keyPrefix) {
  const inline = /\*\*(.+?)\*\*|\[([^\]]+)\]\(([^)]+)\)/g;
  const parts = [];
  let last = 0;
  let match;

  while ((match = inline.exec(text)) !== null) {
    if (match.index > last) parts.push(text.slice(last, match.index));

    const [full, bold, linkText, href] = match;
    const key = `${keyPrefix}-${match.index}`;

    if (bold !== undefined) {
      // Appel récursif : le contenu d'un gras peut lui-même contenir un lien.
      // Le contenu du blog en est plein — « **[Apify](url)** », « **[Guide
      // Complet](...)** ». Sans récursion, le lien ressortait en texte brut,
      // crochets et URL compris, au milieu du paragraphe.
      parts.push(<strong key={key}>{renderInline(bold, `${key}-b`)}</strong>);
    } else if (isExternal(href)) {
      // rel="noopener noreferrer" : sans lui, la page ouverte garde une
      // référence vers la nôtre via window.opener (vecteur de tabnabbing).
      parts.push(
        <a key={key} href={href} target="_blank" rel="noopener noreferrer" data-cursor="hover">
          {linkText}
        </a>,
      );
    } else {
      // Lien interne : href simple plutôt que <Link>, parce que le markdown
      // peut pointer n'importe où et qu'on ne veut pas d'un routeur qui avale
      // silencieusement une URL inconnue.
      parts.push(
        <a key={key} href={href} data-cursor="hover">
          {linkText}
        </a>,
      );
    }
    last = match.index + full.length;
  }

  if (last < text.length) parts.push(text.slice(last));
  return parts.length ? parts : text;
}

// ✅ / ❌ en tête d'item : ce sont des marqueurs sémantiques (avantage /
// inconvénient), pas de la décoration. On les sort du flux de texte pour en
// faire une pastille alignée — sinon la ligne se désaligne et l'emoji hérite
// de la taille du corps, ce qui bave sur les écrans non-retina.
const MARKERS = { '✅': 'ok', '❌': 'ko' };

function renderListItem(raw, key) {
  const text = raw.trim();
  const marker = MARKERS[text.slice(0, 2)] ?? MARKERS[text[0]];

  if (marker) {
    const body = text.replace(/^(✅|❌)\s*/, '');
    return (
      <li key={key} className={`md-li md-li--${marker}`}>
        <span className="md-li__marker" aria-hidden="true" />
        <span>{renderInline(body, key)}</span>
      </li>
    );
  }
  return (
    <li key={key} className="md-li">
      {renderInline(text, key)}
    </li>
  );
}

const splitRow = (line) =>
  line
    .trim()
    .replace(/^\||\|$/g, '')
    .split('|')
    .map((c) => c.trim());

const isTableSep = (line) => /^\|?[\s:-]+\|[\s|:-]*$/.test(line ?? '');

export default function ArticleBody({ content }) {
  // useMemo : le parsing est linéaire mais il tourne sur ~3 000 caractères et
  // le composant re-render à chaque changement de section active du sommaire.
  const blocks = useMemo(() => parse(content), [content]);
  return <div className="md">{blocks}</div>;
}

function parse(markdown) {
  const lines = markdown.split('\n');
  const blocks = [];
  let i = 0;
  let seenH1 = false;

  const push = (node) => blocks.push(<Fragment key={blocks.length}>{node}</Fragment>);

  while (i < lines.length) {
    const line = lines[i];
    const trimmed = line.trim();

    if (!trimmed) {
      i += 1;
      continue;
    }

    // Règle horizontale. Testée AVANT les listes : `---` correspond aussi au
    // début d'un item de liste à puces, et la liste gagnerait sinon.
    if (/^-{3,}$/.test(trimmed)) {
      push(<hr className="md-hr" />);
      i += 1;
      continue;
    }

    // Titres. Le premier # est ignoré : il répète mot pour mot le titre déjà
    // affiché dans l'en-tête de la page, et deux <h1> sur une même page, c'est
    // une faute d'accessibilité (structure de document ambiguë au lecteur
    // d'écran) autant qu'une redondance visuelle.
    const heading = /^(#{1,3})\s+(.*)$/.exec(trimmed);
    if (heading) {
      const level = heading[1].length;
      const text = heading[2].trim();

      if (level === 1) {
        if (!seenH1) {
          seenH1 = true;
          i += 1;
          continue;
        }
        push(<h2 id={slugify(text)} className="md-h2">{renderInline(text, `h-${i}`)}</h2>);
      } else if (level === 2) {
        push(
          <h2 id={slugify(text)} className="md-h2">
            {renderInline(text, `h-${i}`)}
          </h2>,
        );
      } else {
        push(<h3 className="md-h3">{renderInline(text, `h-${i}`)}</h3>);
      }
      i += 1;
      continue;
    }

    // Tableau : une ligne de cellules SUIVIE d'une ligne de séparation. Sans
    // cette seconde condition, une phrase contenant des barres verticales
    // serait avalée comme un tableau à une ligne.
    if (trimmed.startsWith('|') && isTableSep(lines[i + 1])) {
      const head = splitRow(trimmed);
      i += 2;
      const rows = [];
      while (i < lines.length && lines[i].trim().startsWith('|')) {
        rows.push(splitRow(lines[i]));
        i += 1;
      }
      push(
        // overflow-x sur le conteneur, jamais sur la page : un tableau large
        // ne doit pas faire scroller horizontalement tout l'article.
        <div className="md-table-wrap">
          <table className="md-table">
            <thead>
              <tr>
                {head.map((cell, c) => (
                  <th key={c} scope="col">{renderInline(cell, `th-${c}`)}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row, r) => (
                <tr key={r}>
                  {row.map((cell, c) => (
                    <td key={c}>{renderInline(cell, `td-${r}-${c}`)}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>,
      );
      continue;
    }

    // Listes. On accumule les lignes consécutives du même type pour produire
    // UNE liste, et pas une liste par item.
    const bullet = /^-\s+(.*)$/.exec(trimmed);
    const numbered = /^\d+\.\s+(.*)$/.exec(trimmed);

    if (bullet || numbered) {
      const ordered = Boolean(numbered);
      const items = [];
      while (i < lines.length) {
        const t = lines[i].trim();
        const b = /^-\s+(.*)$/.exec(t);
        const n = /^\d+\.\s+(.*)$/.exec(t);
        if (ordered && n) items.push(n[1]);
        else if (!ordered && b) items.push(b[1]);
        else break;
        i += 1;
      }
      const List = ordered ? 'ol' : 'ul';
      push(
        <List className={`md-list ${ordered ? 'md-list--ol' : ''}`}>
          {items.map((item, k) => renderListItem(item, `li-${i}-${k}`))}
        </List>,
      );
      continue;
    }

    // Paragraphe : on agrège les lignes jusqu'à la prochaine ligne vide ou au
    // prochain bloc structuré, pour respecter les retours à la ligne souples
    // du markdown.
    const para = [];
    while (i < lines.length) {
      const t = lines[i].trim();
      if (!t || /^(#{1,3}\s|-\s|\d+\.\s|\||-{3,}$)/.test(t)) break;
      para.push(t);
      i += 1;
    }
    if (para.length) {
      push(<p className="md-p">{renderInline(para.join(' '), `p-${i}`)}</p>);
    }
  }

  return blocks;
}
