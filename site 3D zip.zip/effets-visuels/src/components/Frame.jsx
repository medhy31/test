import { useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { scrollState } from '../three/scrollStore';

const LINKS = [
  { to: '/realisations', label: 'Réalisations' },
  { to: '/blog', label: 'Journal' },
  { to: '/services', label: 'Services' },
  { to: '/a-propos', label: 'À propos' },
  { to: '/contact', label: 'Contact' },
];

// Correspondance par préfixe : l'onglet « Journal » doit rester allumé quand on
// ouvre un article (/blog/linkedin-scraping), on est toujours dans la même
// section du site.
const isOn = (pathname, to) => pathname === to || pathname.startsWith(`${to}/`);

/**
 * Le cadre d'interface : marque, navigation, compteur de progression. Fixe
 * par-dessus tout, il ne défile jamais — ce sont les seuls repères stables
 * pendant qu'on traverse la scène.
 *
 * Le compteur s'anime dans sa PROPRE boucle rAF, et non dans le useFrame du
 * canvas, pour deux raisons : le cadre doit fonctionner sur les pages sans
 * scène 3D (un article, par exemple), et la valeur est écrite directement dans
 * le DOM — la passer par un état React re-rendrait l'arbre à chaque image pour
 * changer deux caractères.
 */
export default function Frame({ note = "Atelier d'automatisation — 2026", meter = true }) {
  const { pathname } = useLocation();
  const fillRef = useRef(null);
  const numRef = useRef(null);

  useEffect(() => {
    if (!meter) return undefined;
    let raf;
    let last = -1;

    const tick = () => {
      const p = scrollState.progress;
      // On n'écrit que si la valeur affichée change réellement : sans ce test,
      // c'est une écriture DOM par image même page immobile.
      const pct = Math.round(p * 100);
      if (pct !== last) {
        last = pct;
        if (fillRef.current) fillRef.current.style.transform = `scaleX(${p})`;
        if (numRef.current) numRef.current.textContent = String(pct).padStart(2, '0');
      }
      raf = requestAnimationFrame(tick);
    };

    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [meter]);

  return (
    <div className="frame">
      <div className="frame__top">
        <Link to="/" className="mark">
          <span className="mark__dot" aria-hidden="true" />
          Romain
        </Link>
        <nav className="nav" aria-label="Navigation principale">
          {LINKS.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              data-on={isOn(pathname, link.to) ? 'true' : undefined}
              aria-current={isOn(pathname, link.to) ? 'page' : undefined}
            >
              {link.label}
            </Link>
          ))}
        </nav>
      </div>

      <div className="frame__bottom">
        <p className="t-tag">{note}</p>
        {meter && (
          <div className="meter">
            <span className="meter__now" ref={numRef}>
              00
            </span>
            <span className="meter__track">
              <span className="meter__fill" ref={fillRef} style={{ transform: 'scaleX(0)' }} />
            </span>
            <span>100</span>
          </div>
        )}
      </div>
    </div>
  );
}
