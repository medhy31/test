import { BESOINS } from '../content/diagnostic';

/**
 * Le choix du besoin — première étape de la qualification.
 *
 * Partagé par la page d'accueil et le parcours lui-même. Sur l'accueil, le
 * visiteur commence à répondre sans avoir eu à cliquer sur un bouton : c'est
 * une action beaucoup moins coûteuse qu'un « prendre rendez-vous », et une fois
 * la première réponse donnée, on finit rarement un parcours à mi-chemin.
 *
 * Les deux emplacements partagent donc le même composant, pour qu'une
 * modification de la liste ne diverge jamais entre les deux.
 */
export default function ChoixBesoin({ onChoix }) {
  return (
    <ul className="choix">
      {BESOINS.map((besoin) => (
        <li key={besoin.id}>
          <button type="button" className="choix__item" onClick={() => onChoix(besoin.id)}>
            <span className="choix__main">
              <span className="choix__title">{besoin.title}</span>
              <span className="choix__desc t-body">{besoin.description}</span>
            </span>
            <span className="choix__go" aria-hidden="true">
              →
            </span>
          </button>
        </li>
      ))}
    </ul>
  );
}
