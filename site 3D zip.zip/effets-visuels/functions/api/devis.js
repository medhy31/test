/**
 * POST /api/devis — réception des demandes du formulaire.
 *
 * Cette fonction est exécutée par l'hébergeur, à la même adresse que le site.
 * Trois conséquences qui justifient de ne pas appeler n8n depuis le navigateur :
 *
 *   1. Le HTTPS est celui du site : plus besoin d'exposer une instance n8n sur
 *      Internet, ni d'un nom de domaine pour la certifier.
 *   2. Le jeton du bot Telegram reste ici. Placé dans le code du site, il serait
 *      lisible par n'importe quel visiteur — un jeton de bot permet de lire et
 *      d'écrire tous ses messages.
 *   3. Même origine, donc aucune requête préparatoire CORS.
 *
 * Variables à définir sur la plateforme (jamais dans le dépôt) :
 *   TELEGRAM_TOKEN  jeton du bot, donné par BotFather        (obligatoire)
 *   TELEGRAM_CHAT   identifiant de la conversation           (obligatoire)
 *   N8N_WEBHOOK     URL n8n à alimenter en plus, si un jour  (facultatif)
 *                   le traitement dépasse la simple alerte
 */

// Un formulaire de six champs courts n'a aucune raison de peser davantage ;
// au-delà, c'est un abus et on refuse sans lire.
const TAILLE_MAX = 4000;

// Ordre d'affichage dans l'alerte : ce qu'on lit en premier pour décider si on
// rappelle, pas l'ordre dans lequel le formulaire les a collectés.
const CHAMPS = [
  ['email', 'Email'],
  ['besoin', 'Besoin'],
  ['secteur', 'Secteur'],
  ['volume', 'Volume'],
  ['budget', 'Budget'],
  ['solution', 'Proposition affichée'],
];

const json = (corps, statut = 200) =>
  new Response(JSON.stringify(corps), {
    status: statut,
    headers: { 'Content-Type': 'application/json' },
  });

/** Ramène une valeur quelconque à une ligne de texte affichable. */
function propre(valeur) {
  if (typeof valeur !== 'string') return '';
  // Les retours à la ligne permettraient de fabriquer de faux champs dans
  // l'alerte reçue ; on les écrase.
  return valeur.replace(/\s+/g, ' ').trim().slice(0, 300);
}

export async function onRequestPost({ request, env }) {
  const taille = Number(request.headers.get('content-length') || 0);
  if (taille > TAILLE_MAX) return json({ ok: false }, 413);

  let brut;
  try {
    brut = await request.json();
  } catch {
    return json({ ok: false }, 400);
  }

  const donnees = Object.fromEntries(CHAMPS.map(([cle]) => [cle, propre(brut?.[cle])]));

  // Seul l'email est vraiment indispensable : sans lui la demande ne sert à
  // rien, puisqu'on ne peut pas répondre. Le reste peut manquer.
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(donnees.email)) {
    return json({ ok: false, erreur: 'email' }, 400);
  }

  const recuLe = new Date().toLocaleString('fr-FR', {
    timeZone: 'Europe/Paris',
    dateStyle: 'short',
    timeStyle: 'short',
  });

  const texte = [
    'Nouvelle demande de devis',
    '',
    ...CHAMPS.filter(([cle]) => donnees[cle]).map(([cle, libelle]) => `${libelle} : ${donnees[cle]}`),
    '',
    `Reçue le ${recuLe}`,
  ].join('\n');

  // L'alerte et le relais n8n partent ensemble : l'un ne doit pas retarder
  // l'autre, et l'échec de l'un ne doit pas emporter le second.
  const envois = [
    fetch(`https://api.telegram.org/bot${env.TELEGRAM_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: env.TELEGRAM_CHAT, text: texte }),
    }),
  ];

  if (env.N8N_WEBHOOK) {
    envois.push(
      fetch(env.N8N_WEBHOOK, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...donnees, recu_le: recuLe }),
      }),
    );
  }

  const resultats = await Promise.allSettled(envois);
  // On ne confirme que si l'alerte est réellement partie. Un « c'est noté »
  // affiché alors que personne n'a été prévenu, c'est un lead perdu en silence
  // — précisément le mode de panne que le repli par email existe pour couvrir.
  const alerte = resultats[0];
  if (alerte.status !== 'fulfilled' || !alerte.value.ok) return json({ ok: false }, 502);

  return json({ ok: true });
}
