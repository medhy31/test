#!/usr/bin/env node
/**
 * parcours.cjs — traverse le formulaire de qualification étape par étape et
 * capture chacune d'elles.
 *
 * look.cjs ne sait que naviguer et défiler : il ne peut pas voir les étapes 2
 * à 4, qui n'existent qu'après un clic. Ce script clique réellement, comme un
 * visiteur, et prend une image à chaque écran.
 */

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');

const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const PORT = 9222;
const PROFILE = '/tmp/claude-chrome-look-profile';
const OUT = path.join(__dirname, 'captures');
fs.mkdirSync(OUT, { recursive: true });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const getJSON = (url) => fetch(url).then((r) => r.json());

async function ensureChrome() {
  try {
    await getJSON(`http://127.0.0.1:${PORT}/json/version`);
    return;
  } catch {
    /* à lancer */
  }
  spawn(
    CHROME,
    [
      `--remote-debugging-port=${PORT}`,
      `--user-data-dir=${PROFILE}`,
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-extensions',
      '--window-size=1440,900',
      '--window-position=2400,0',
      'about:blank',
    ],
    { detached: true, stdio: 'ignore' },
  ).unref();
  for (let i = 0; i < 40; i += 1) {
    await sleep(400);
    try {
      await getJSON(`http://127.0.0.1:${PORT}/json/version`);
      return;
    } catch {
      /* on réessaie */
    }
  }
  throw new Error('Chrome injoignable');
}

class CDP {
  constructor(ws) {
    this.ws = ws;
    this.id = 0;
    this.pending = new Map();
    ws.on('message', (raw) => {
      const m = JSON.parse(raw);
      if (m.id && this.pending.has(m.id)) {
        const { resolve, reject } = this.pending.get(m.id);
        this.pending.delete(m.id);
        m.error ? reject(new Error(m.error.message)) : resolve(m.result);
      }
    });
  }
  send(method, params = {}) {
    const id = (this.id += 1);
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }
}

async function main() {
  const url = process.argv[2] || 'http://localhost:5173/demarrer';
  await ensureChrome();

  const res = await fetch(`http://127.0.0.1:${PORT}/json/new?about:blank`, { method: 'PUT' });
  const target = await res.json();
  const ws = new WebSocket(target.webSocketDebuggerUrl, { perMessageDeflate: false });
  await new Promise((r) => ws.on('open', r));
  const cdp = new CDP(ws);

  await cdp.send('Page.enable');
  await cdp.send('Runtime.enable');
  await cdp.send('Emulation.setDeviceMetricsOverride', {
    width: 1440,
    height: 900,
    deviceScaleFactor: 1,
    mobile: false,
  });
  await cdp.send('Page.navigate', { url });
  await sleep(4500);

  const shot = async (nom) => {
    const img = await cdp.send('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync(path.join(OUT, `${nom}.png`), Buffer.from(img.data, 'base64'));
    return nom;
  };

  const clic = async (expression) => {
    const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true });
    await sleep(900);
    return r.result.value;
  };

  const faits = [];

  faits.push(await shot('D-start-1-besoin'));

  // Étape 1 : choisir le deuxième besoin (« Automatiser mes workflows »).
  await clic(`document.querySelectorAll('.choix__item')[1].click(), true`);
  faits.push(await shot('D-start-2-contexte'));

  // Étape 2 : renseigner les trois listes. On passe par le setter natif puis un
  // évènement 'change' : affecter .value directement ne prévient pas React, qui
  // garderait son état à vide et laisserait le bouton désactivé.
  await clic(`(() => {
    const set = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, 'value').set;
    const choix = { sector: 'SaaS', volume: 'Moyen (1K - 100K données/jour)', budget: '1000-5000€' };
    for (const [id, valeur] of Object.entries(choix)) {
      const el = document.getElementById(id);
      set.call(el, valeur);
      el.dispatchEvent(new Event('change', { bubbles: true }));
    }
    return true;
  })()`);
  faits.push(await shot('D-start-2b-rempli'));

  await clic(`[...document.querySelectorAll('.act')].find(b => b.textContent.includes('Continuer')).click(), true`);
  faits.push(await shot('D-start-3-solution'));

  await clic(`[...document.querySelectorAll('.act')].find(b => b.textContent.includes('devis')).click(), true`);
  faits.push(await shot('D-start-4-contact'));

  await clic(`(() => {
    const set = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    const el = document.getElementById('email');
    set.call(el, 'test-formulaire@exemple.fr');
    el.dispatchEvent(new Event('input', { bubbles: true }));
    return true;
  })()`);
  await clic(`[...document.querySelectorAll('.act')].find(b => b.textContent.includes('Demander')).click(), true`);
  faits.push(await shot('D-start-5-succes'));

  console.log('CAPTURES :', faits.join(', '));

  await cdp.send('Page.close').catch(() => {});
  ws.close();
  process.exit(0);
}

main().catch((e) => {
  console.error('ECHEC:', e.message);
  process.exit(1);
});
