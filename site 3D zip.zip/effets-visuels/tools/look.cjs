#!/usr/bin/env node
/**
 * look.js — regarde une page dans un vrai Chrome (vrai GPU) et en ramène :
 *   - des captures d'écran à plusieurs positions de défilement
 *   - les erreurs et avertissements de la console
 *   - une mesure d'images par seconde
 *
 * Pourquoi ce détour : `chrome --headless --screenshot` rend le WebGL en
 * logiciel (SwiftShader), ce qui est trop lent pour aboutir sur une scène 3D,
 * et ne dit rien des erreurs ni du framerate. Ici on pilote un Chrome normal
 * via le protocole de débogage (CDP), donc avec le GPU de la machine.
 *
 * Usage :
 *   node look.js <url> <prefixe-sortie> [positions...]
 *   node look.js http://localhost:5173/ home 0 0.25 0.5 0.75 1
 */

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');

const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const PORT = 9222;
const PROFILE = '/tmp/claude-chrome-look-profile';
const OUT_DIR = path.join(__dirname, 'captures');
fs.mkdirSync(OUT_DIR, { recursive: true });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function getJSON(url) {
  const res = await fetch(url);
  return res.json();
}

async function ensureChrome() {
  try {
    const v = await getJSON(`http://127.0.0.1:${PORT}/json/version`);
    return v.webSocketDebuggerUrl;
  } catch {
    // pas encore lancé
  }

  // Profil dédié : on ne touche jamais au profil personnel (sessions, cookies,
  // extensions). --window-position hors du champ visible pour ne pas voler le
  // focus pendant que l'utilisateur travaille.
  spawn(
    CHROME,
    [
      `--remote-debugging-port=${PORT}`,
      `--user-data-dir=${PROFILE}`,
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-extensions',
      '--window-size=1440,900',
      '--window-position=2400,0',
      'about:blank',
    ],
    { detached: true, stdio: 'ignore' },
  ).unref();

  for (let i = 0; i < 40; i += 1) {
    await sleep(400);
    try {
      const v = await getJSON(`http://127.0.0.1:${PORT}/json/version`);
      return v.webSocketDebuggerUrl;
    } catch {
      /* on réessaie */
    }
  }
  throw new Error("Chrome n'a pas ouvert son port de debogage");
}

/** Petit client CDP : envoie des commandes, écoute les événements. */
class CDP {
  constructor(ws) {
    this.ws = ws;
    this.id = 0;
    this.pending = new Map();
    this.listeners = [];
    ws.on('message', (raw) => {
      const msg = JSON.parse(raw);
      if (msg.id && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        msg.error ? reject(new Error(msg.error.message)) : resolve(msg.result);
      } else if (msg.method) {
        this.listeners.forEach((fn) => fn(msg));
      }
    });
  }

  send(method, params = {}) {
    const id = (this.id += 1);
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }

  on(fn) {
    this.listeners.push(fn);
  }
}

async function main() {
  const [url, prefix = 'shot', ...rest] = process.argv.slice(2);
  if (!url) {
    console.error('usage: node look.js <url> <prefixe> [positions 0..1]');
    process.exit(1);
  }
  const positions = rest.length ? rest.map(Number) : [0, 0.5, 1];

  await ensureChrome();

  // Onglet neuf pour cette inspection.
  const target = await getJSON(
    `http://127.0.0.1:${PORT}/json/new?${encodeURIComponent('about:blank')}`,
  ).catch(async () => {
    // Chrome récent refuse GET sur /json/new : on repasse en PUT.
    const res = await fetch(
      `http://127.0.0.1:${PORT}/json/new?${encodeURIComponent('about:blank')}`,
      { method: 'PUT' },
    );
    return res.json();
  });

  const ws = new WebSocket(target.webSocketDebuggerUrl, { perMessageDeflate: false });
  await new Promise((r) => ws.on('open', r));
  const cdp = new CDP(ws);

  const logs = [];
  cdp.on((msg) => {
    if (msg.method === 'Runtime.consoleAPICalled') {
      const { type, args } = msg.params;
      if (['error', 'warning', 'assert'].includes(type)) {
        logs.push(`[${type}] ${args.map((a) => a.value ?? a.description ?? '').join(' ')}`);
      }
    }
    if (msg.method === 'Runtime.exceptionThrown') {
      const d = msg.params.exceptionDetails;
      logs.push(`[exception] ${d.text} ${d.exception?.description ?? ''}`);
    }
  });

  await cdp.send('Page.enable');
  await cdp.send('Runtime.enable');
  await cdp.send('Emulation.setDeviceMetricsOverride', {
    width: 1440,
    height: 900,
    deviceScaleFactor: 1,
    mobile: false,
  });

  await cdp.send('Page.navigate', { url });
  await sleep(4500); // laisse le temps au WebGL de s'initialiser

  // Contexte de rendu réellement obtenu (WebGL matériel ou logiciel ?)
  const renderer = await cdp.send('Runtime.evaluate', {
    expression: `(() => {
      const c = document.createElement('canvas');
      const gl = c.getContext('webgl2') || c.getContext('webgl');
      if (!gl) return 'AUCUN WEBGL';
      const dbg = gl.getExtension('WEBGL_debug_renderer_info');
      return dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : 'inconnu';
    })()`,
    returnByValue: true,
  });

  // Mesure d'images par seconde sur une seconde pleine.
  //
  // Course contre un délai : sur une fenêtre entièrement occultée, le
  // navigateur suspend requestAnimationFrame. Sans ce garde-fou, la promesse
  // n'est jamais tenue et tout le script reste bloqué indéfiniment — c'est
  // arrivé. On rend alors `null` plutôt que d'attendre.
  const fps = await cdp.send('Runtime.evaluate', {
    expression: `Promise.race([
      new Promise((resolve) => {
        let n = 0;
        const start = performance.now();
        const tick = () => {
          n += 1;
          if (performance.now() - start < 1000) requestAnimationFrame(tick);
          else resolve(n);
        };
        requestAnimationFrame(tick);
      }),
      new Promise((resolve) => setTimeout(() => resolve(null), 3000)),
    ])`,
    awaitPromise: true,
    returnByValue: true,
  });

  const files = [];
  const positionsAtteintes = [];
  for (const p of positions) {
    // Positionnement en plusieurs passes. Une seule ne suffit pas : la page
    // continue de bouger après le premier saut (polices qui arrivent et
    // changent la hauteur du document, effets au montage qui remettent le
    // défilement à zéro). On repositionne jusqu'à ce que la position tienne,
    // sinon on capture une section pour une autre — et on corrige un défaut
    // qui n'existe pas.
    let atteint = null;
    for (let essai = 0; essai < 4; essai += 1) {
      atteint = (
        await cdp.send('Runtime.evaluate', {
          expression: `(() => {
            const doc = document.documentElement;
            const prev = doc.style.scrollBehavior;
            doc.style.scrollBehavior = 'auto';
            const max = doc.scrollHeight - window.innerHeight;
            window.scrollTo(0, max * ${p});
            doc.style.scrollBehavior = prev;
            return { y: Math.round(window.scrollY), max: Math.round(max),
                     pct: max > 0 ? Math.round((window.scrollY / max) * 100) : 0 };
          })()`,
          returnByValue: true,
        })
      ).result.value;
      await sleep(essai === 0 ? 900 : 450);
      const verif = (
        await cdp.send('Runtime.evaluate', {
          expression: `(() => {
            const max = document.documentElement.scrollHeight - window.innerHeight;
            return max > 0 ? Math.round((window.scrollY / max) * 100) : 0;
          })()`,
          returnByValue: true,
        })
      ).result.value;
      if (Math.abs(verif - Math.round(p * 100)) <= 1) {
        atteint.pct = verif;
        break;
      }
      atteint.pct = verif;
    }

    await sleep(1200); // le lissage de la caméra doit rattraper la position

    // Dernier recalage juste avant de déclencher. La hauteur du document
    // continue de bouger après le premier saut — polices qui arrivent,
    // animation d'entrée de page — et la position dérive donc entre le moment
    // où on la vérifie et celui où on capture. Sans ce recalage final, on
    // photographie une autre section que celle demandée, et on croit corriger
    // un défaut qui n'existe pas.
    const recale = (
      await cdp.send('Runtime.evaluate', {
        expression: `(() => {
          const doc = document.documentElement;
          const prev = doc.style.scrollBehavior;
          doc.style.scrollBehavior = 'auto';
          const max = doc.scrollHeight - window.innerHeight;
          window.scrollTo(0, max * ${p});
          doc.style.scrollBehavior = prev;
          return max > 0 ? Math.round((window.scrollY / max) * 100) : 0;
        })()`,
        returnByValue: true,
      })
    ).result.value;
    await sleep(900);

    positionsAtteintes.push(`${Math.round(p * 100)}%->${recale}%`);

    const shot = await cdp.send('Page.captureScreenshot', { format: 'png' });
    const file = path.join(OUT_DIR, `${prefix}-${String(Math.round(p * 100)).padStart(3, '0')}.png`);
    fs.writeFileSync(file, Buffer.from(shot.data, 'base64'));
    files.push(file);
  }

  console.log('RENDU   :', renderer.result.value);
  // AVERTISSEMENT IMPORTANT : Chrome bride le rafraîchissement des fenêtres
  // qu'il considère non visibles, et celle-ci est ouverte hors de l'écran pour
  // ne pas voler le focus. Une page entièrement statique mesure ~32 ici : tant
  // que le chiffre reste dans cet ordre de grandeur, il ne dit RIEN de la
  // performance réelle. Seul un effondrement très net (moins de 15) est un
  // signal exploitable.
  console.log(
    'IMAGES/S:',
    fps.result.value === null
      ? 'non mesurable (fenêtre occultée, rAF suspendu)'
      : `${fps.result.value} (plafonné ~32 quand la fenêtre est bridée — indicatif seulement)`,
  );
  console.log('CAPTURES:', files.map((f) => path.basename(f)).join(', '));
  console.log('POSITIONS:', positionsAtteintes.join(' | '));
  console.log('CONSOLE :', logs.length ? '' : 'aucune erreur');
  logs.slice(0, 15).forEach((l) => console.log('  ' + l));

  await cdp.send('Page.close').catch(() => {});
  ws.close();
  process.exit(0);
}

main().catch((e) => {
  console.error('ECHEC:', e.message);
  process.exit(1);
});
