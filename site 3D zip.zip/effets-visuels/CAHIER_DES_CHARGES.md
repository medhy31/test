# 📘 Cahier des Charges : Architecture Visuelle & Écosystème 3D

Ce document formalise l'ensemble des technologies, modules 3D, bibliothèques, composants d'interface et démonstrateurs bonus intégrés au projet **Site 3D / Effets Visuels**.

---

## 1. 🎯 Objectifs du Projet
* Offrir une expérience web interactive **luxe & high-tech** combinant WebGL, shaders sur-mesure et micro-interactions ultra-fluides.
* Allier performances (taux de rafraîchissement à 60/120 FPS) et esthétique (réfraction optique, néons, volumétrie, particules).
* Servir de vitrine technologique modulaire pour la présentation de services d'automatisation, de données et d'intelligence artificielle.

---

## 2. 🛠️ Inventaire & Rôles des Outils Techniques

| Outil / Bibliothèque | Version / Source | Fonction & Rôle Technique |
| :--- | :--- | :--- |
| **Three.js** | `^0.185.1` | **Moteur de rendu WebGL principal** : gère le graphe de scène 3D, les caméras, lumières, maillages, textures, shaders et calculs matriciels. |
| **@react-three/fiber (R3F)** | `^9.7.0` | **Passerelle React ↔ Three.js** : permet d'écrire la 3D de manière déclarative en composants React avec cycle de vie optimisé. |
| **@react-three/drei** | `^10.7.8` | **Boîte à outils 3D avancée** : fournit des abstractions prêtes à l'emploi (`Float`, `RoundedBox`, `Environment`, `ScrollControls`, `MeshTransmissionMaterial`, `Edges`, `Text`, `Points`). |
| **@react-three/postprocessing** | `^3.0.5` | **Effets de post-traitement** : application du filtre **Bloom** (lueur néon emissive), gestion du vignettage et de la profondeur de champ. |
| **liquid-glass-js** | Librairie locale | **Moteur de réfraction liquide** : simulation d'interfaces en verre liquide avec distorsion dynamique et réfraction de couche de fond. |
| **Framer Motion** | `^13.1.0` | **Moteur d'animation UI / DOM** : gère les transitions de pages (`AnimatePresence`), apparitions au scroll, boutons magnétiques et effets de reveal. |
| **Lucide React** | `^1.31.0` | **Système iconographique** : icônes SVG modernes, légères et uniformes. |
| **Vite & Oxlint** | Vite 8 + Oxlint | **Pipeline de build & Tooling** : HMR ultra-rapide et analyse statique du code. |
| **Outils IA & Médias** | ImageMagick / Rembg / Replicate | **Génération et détourage d'assets** : traitement d'images haute résolution et suppression automatique d'arrière-plans. |

---

## 3. 💎 Description des 3 Exemples Majeurs

### A. 🌀 Démo 1 — Le Scrollytelling / Tunnel Vectoriel (`Demo1.jsx`)
* **Fonction :** Navigation immersive où le défilement (scroll) de l'utilisateur déplace la caméra le long d'une courbe 3D ([`THREE.CatmullRomCurve3`](file:///Users/macbook/Desktop/site%203D/effets-visuels/src/pages/Demo1.jsx#L12-L19)).
* **Technologie Drei :** `ScrollControls` + composant `Tube` avec maillage wireframe lumineux et atténuation par brume (`fog`).
* **Cas d'usage :** Storytelling interactif, visite guidée d'un pipeline ou d'un flux de données.

### B. 🔮 Démo 2 — L'Objet Hero en Verre Réaliste (`Demo2.jsx`)
* **Fonction :** Présentation d'un objet central complexe (nœud torique) avec transmission optique et diffraction réaliste.
* **Technologie Drei :** `MeshTransmissionMaterial` (réglages d'`ior: 1.5`, épaisseur `thickness`, aberration chromatique `0.06`, rugosité `roughness: 0`).
* **Éclairage :** Carte HDRI `city` via `<Environment preset="city" />` pour des reflets spéculaires et une brillance de qualité showroom.

### C. 🌌 Démo 3 — Le Nuage de Particules IA & Big Data (`Demo3.jsx`)
* **Fonction :** Sphère vivante de 5 000 particules néon cyan en rotation continue simulant l'activité d'un réseau neuronal ou d'un cœur de calcul.
* **Technologie :** `Float32Array` avec coordonnées trigonométriques sphériques distribuées, rendu via `<Points />` et `<PointMaterial />` avec `sizeAttenuation` pour la profondeur.

---

## 4. 🎁 Les Fonctionnalités & Démonstrateurs Bonus

### 🏙️ Bonus 1 : La Mini-Ville Isométrique Interactive (`FinalDemo.jsx` & `Demo4.jsx`)
* **Fonction :** Ville modélisée en 3D isométrique où chaque gratte-ciel représente un pôle de service (Data Center, Analytics, API).
* **Interactivité :** 
  * Au clic sur un bâtiment, les structures secondaires s'enfoncent dans le sol grâce à une interpolation `lerp`.
  * La caméra effectue un travelling dynamique pour cadrer le module sélectionné et dévoiler sa fiche descriptive détaillée.

### 🪟 Bonus 2 : Le Fond 3D Permanent Glassmorphism (`GlassBackground.jsx`)
* **Fonction :** Arrière-plan global persistant partagé sur toutes les pages via un unique contexte Canvas WebGL.
* **Composition :**
  * Plaque centrale de dashboard en verre transparent avec liaisons de nœuds data.
  * Rayons lasers néon tubulaires (courbes Catmull-Rom cyan et violette).
  * Cubes de verre flottants avec arêtes lumineuses réagissant aux mouvements de souris (parallaxe).

### ⚡ Bonus 3 : Arrière-plan Circuits Data SVG (`WorkflowBackground.jsx`)
* **Fonction :** Réseau de flux vectoriels avec paquets de lumière animés le long de tracés SVG (`offset-path` et filtres `drop-shadow`).
* **Avantage :** Poids plume, 0% de charge CPU/GPU WebGL, idéal pour des sections de dashboard ou pages secondaires.

### ✨ Bonus 4 : Composants UI Micro-Interactifs
* **Curseur Custom (`Cursor.jsx`) :** Cercle suiveur avec lissage physique et agrandissement dynamique au survol d'éléments cliquables.
* **Cartes 3D au survol (`TiltCard.jsx`) :** Rotation 3D basée sur la position relative de la souris sur la carte.
* **Bouton Magnétique (`MagneticButton.jsx`) :** Attire le bouton vers le curseur pour un ressenti haut de gamme.
* **Écran de Chargement (`Preloader.jsx`) :** Transition fluide lors de l'initialisation de l'application.

---

## 5. 🗺️ Matrice des Routes de l'Application

| Route URL | Composant | Description |
| :--- | :--- | :--- |
| `/` | [`Home.jsx`](file:///Users/macbook/Desktop/site%203D/effets-visuels/src/pages/Home.jsx) | Page d'accueil officielle avec fond verre 3D interactif et sections de services |
| `/services` | [`Services.jsx`](file:///Users/macbook/Desktop/site%203D/effets-visuels/src/pages/Services.jsx) | Grille détaillée des prestations et expertises |
| `/contact` | [`Contact.jsx`](file:///Users/macbook/Desktop/site%203D/effets-visuels/src/pages/Contact.jsx) | Formulaire de mise en relation stylisé en glassmorphism |
| `/demo1` | [`Demo1.jsx`](file:///Users/macbook/Desktop/site%203D/effets-visuels/src/pages/Demo1.jsx) | Scrollytelling : Tunnel 3D guidé |
| `/demo2` | [`Demo2.jsx`](file:///Users/macbook/Desktop/site%203D/effets-visuels/src/pages/Demo2.jsx) | Hero Glass : Réfraction optique et matériau de verre physique |
| `/demo3` | [`Demo3.jsx`](file:///Users/macbook/Desktop/site%203D/effets-visuels/src/pages/Demo3.jsx) | Nuage de particules : Représentation Big Data / Algorithmes |
| `/demo4` | [`Demo4.jsx`](file:///Users/macbook/Desktop/site%203D/effets-visuels/src/pages/Demo4.jsx) | Démonstrateur blocs isométriques flottants |
| `/final` | [`FinalDemo.jsx`](file:///Users/macbook/Desktop/site%203D/effets-visuels/src/pages/FinalDemo.jsx) | Scène finale : Ville 3D interactive complète avec zoom et inspection |
